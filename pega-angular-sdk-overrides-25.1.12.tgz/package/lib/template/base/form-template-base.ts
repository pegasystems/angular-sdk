import { Directive, OnDestroy } from '@angular/core';
import { AngularPConnectData } from '@pega/angular-sdk-components';

@Directive()
export class FormTemplateBase implements OnDestroy {
  pConn$: any;
  angularPConnectData: AngularPConnectData;

  ngOnDestroy(): void {
    PCore.getContextTreeManager().removeContextTreeNode(this.pConn$.getContextName());

    if (this.angularPConnectData?.unsubscribeFn) {
      this.angularPConnectData.unsubscribeFn();
    }
  }
}
