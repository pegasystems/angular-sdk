import * as i0 from '@angular/core';
import { OnInit, OnDestroy, OnChanges, ViewContainerRef, ComponentRef, SimpleChanges, EventEmitter, Injector, ChangeDetectorRef, NgZone, TemplateRef, AfterViewInit, ElementRef, Renderer2 } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable, Subscription } from 'rxjs';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import * as _angular_common_http from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { NgxCurrencyInputMode } from 'ngx-currency';
import * as _angular_cdk_overlay from '@angular/cdk/overlay';
import * as _pega_pcore_pconnect_typedefs_interpreter_types from '@pega/pcore-pconnect-typedefs/interpreter/types';
import { ComponentMetadataConfig } from '@pega/pcore-pconnect-typedefs/interpreter/types';
import { MatSnackBar } from '@angular/material/snack-bar';
import { publicConstants } from '@pega/pcore-pconnect-typedefs/constants';
import * as _pega_pcore_pconnect_typedefs_interpreter_c11n_env from '@pega/pcore-pconnect-typedefs/interpreter/c11n-env';
import * as _pega_pcore_pconnect_typedefs_locale_locale_utils from '@pega/pcore-pconnect-typedefs/locale/locale-utils';
import { MatDialog } from '@angular/material/dialog';
import * as _pega_pcore_pconnect_typedefs_analytics_types_data_model from '@pega/pcore-pconnect-typedefs/analytics/types/data-model';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

declare class ComponentMapperComponent implements OnInit, OnDestroy, OnChanges {
    dynamicComponent: ViewContainerRef | undefined;
    componentRef: ComponentRef<any> | undefined;
    isInitialized: boolean;
    name?: string;
    props: any;
    errorMsg: string;
    outputEvents: any;
    parent: any;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    loadComponent(): void;
    bindInputProps(): void;
    bindOutputEvents(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ComponentMapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ComponentMapperComponent, "component-mapper", never, { "name": { "alias": "name"; "required": false; }; "props": { "alias": "props"; "required": false; }; "errorMsg": { "alias": "errorMsg"; "required": false; }; "outputEvents": { "alias": "outputEvents"; "required": false; }; "parent": { "alias": "parent"; "required": false; }; }, {}, never, never, true, never>;
}

declare let SdkComponentMap: any;
declare function getSdkComponentMap(inLocalComponentMap?: {}): Promise<unknown>;
declare function getComponentFromMap(inComponentName: string): any;

declare class ProgressSpinnerService {
    private subject;
    /**
     * Function to show/hide spinner
     * @param bShow - true: show spinner, false: hide spinner
     */
    sendMessage(bShow: boolean): void;
    clearMessage(): void;
    getMessage(): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressSpinnerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProgressSpinnerService>;
}

declare class ErrorMessagesService {
    private subject;
    /**
     *
     * @param sAction - show, dismiss
     * @param sActionMessage - text to displayed, will be queued with others until dismiss
     */
    sendMessage(sAction: string, sActionMessage: string): void;
    clearMessage(): void;
    getMessage(): Observable<void | object>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorMessagesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorMessagesService>;
}

declare class ServerConfigService {
    /**
     * Asynchronous initialization of the config file contents.
     * @returns Promise of config file fetch
     */
    readSdkConfig(): Promise<any>;
    /**
     *
     * @returns the sdk-config JSON object
     */
    getSdkConfig(): Promise<any>;
    /**
     *
     * @returns the authConfig block in the SDK Config object
     */
    getSdkConfigAuth(): Promise<any>;
    /**
     *
     * @returns the serverConfig bloc from the sdk-config.json file
     */
    getSdkConfigServer(): any;
    /**
     * @param {String} key the key to be inserted/updated in serverConfig
     * @param {String} value the value to be assigned to the given key
     */
    setSdkConfigServer(key: string, value: string): void;
    getBaseUrl(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ServerConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ServerConfigService>;
}

declare class Utils {
    private scService;
    lastControlID: number;
    viewContainerCount: number;
    timezone: string | undefined;
    constructor(scService: ServerConfigService);
    getSDKStaticContentUrl(): string;
    consoleKidDump(pConn: any, level?: number, kidNum?: number): void;
    htmlDecode(sVal: string): string | null;
    getUniqueControlID(): string;
    getOptionList(configProps: any, dataObject: any): any[];
    handleAssociatedList(configProps: any): any[];
    handleDataPageList(configProps: any, dataObject: any): any[];
    transformListSourceItems(listSourceItems: any[]): any[];
    getInitials(userName: string): string;
    getImageSrc(name: string, serverUrl: string): string;
    getIconPath(serverUrl: string): string;
    getBooleanValue(inValue: any): boolean;
    generateDate(dateVal: any, dateFormat: any): any;
    generateDateTime(dateTimeVal: any, dateFormat: any): any;
    getIconFromFileType(fileType: any): string;
    getIconForAttachment(attachment: any): any;
    addViewContainer(): void;
    removeViewContainer(): void;
    okToAddContainerToVC(): boolean;
    getUserId: (user: any) => string;
    static sdkGetAuthHeader(): string;
    static isEmptyObject(obj: object): boolean;
    /**
     * Get a localized value from the Generic Fields
     * @param path - The path within Generic Fields (e.g., 'CosmosFields.fields.lists')
     * @param key - The key of the string to localize
     * @returns The localized string or the key itself if no translation is found
     */
    getGenericFieldsLocalizedValue(path: string, key: string): string;
    prepareComponentInCaseSummary(pConnectMeta: any, getPConnect: any): any;
    resolveReferenceFields(item: {
        [key: string]: unknown;
    }, hideFieldLabels: boolean, recordKey: string, pConnect: typeof PConnect): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<Utils, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Utils>;
}

interface AngularPConnectData {
    compID?: string;
    unsubscribeFn?: Function;
    validateMessage?: string;
    actions?: {
        onChange: Function;
        onBlur: Function;
    };
}
declare class AngularPConnectService {
    private psService;
    private erService;
    private utils;
    /**
     * Local variable for access to the store once the service is connected to it.
     */
    private theStore;
    /**
     * Local variable used to compute the next componentID
     */
    private counterComponentID;
    /**
     * Local array used to store the association of an component to its most recent "props"
     *  where "props" is the object containing the component's getConfigProps along with
     * anything added by populateAdditionalProps.
     * Each entry is: { __componentID__: _the component's most recent props_ }
     */
    private componentPropsArr;
    private static bLogging;
    constructor(psService: ProgressSpinnerService, erService: ErrorMessagesService, utils: Utils);
    /**
     * Returns a unique (for this session) ComponentID that should
     * be used for that component to update its most recent props
     * (which can also be compared against its previous value
     * before updating). Note that this returns a string so we can use
     * it as a key in an associative array
     * @returns the next componentID
     */
    private getNextComponentId;
    /**
     * The Calling object (inComp) subscribes to store changes.
     * @param inComp The component that's subscribing to the store
     * @param inCallback The component's callback function (typically called onStateChange) that will
     * be called when the store changes.
     * @returns The **unsubscribe** function that should be called when the component needs
     * to unsubscribe from the store. (Typically during ngOnDestroy)
     */
    private subscribeToStore;
    /**
     * Gets the Component's properties that are used (a) to populate componentPropsArr
    //  and (b) to determine whether the component should update itself (re-render)
     * @param inComp The component whose properties are being obtained
     */
    private getComponentProps;
    /**
     * Returns the unique id for given component created when registering
     * Otherwise, return undefined.
     * @param inComp The component whose property is being requested.
     */
    getComponentID(inComp: any): string;
    /**
     * Returns the value of requested property for the component if it exists.
     * Otherwise, return undefined.
     * @param inComp The component whose property is being requested.
     * @param inProp The property being requested.
     */
    getComponentProp(inComp?: any, inProp?: string): any;
    /**
     *
     * @returns The current complete set of resolved properties that are associated with
     * this component.
     * This is the full set of properties that are tracked in Redux for this component.
     */
    getCurrentCompleteProps(inComp?: any): object;
    /**
     * Registers the component and its callback function. When a component calls this method
     * (typically from its ngOnInit), the component is given a unique componentID (for this session)
     * and subscribes the component to the store. As a side effect, it also assigns the component's
     * actions (from its metadata) to the component's ___actions___ and binds the component's callback
     * (passed in as ___inCallback___) to the component. If a problem is encountered, an empty object,
     * {}, is returned.
     * @param inComp The component being registered and subscribed
     * @param inCallback The component's callback function (typically called onStateChange) that
     * will be called whenever the state changes.
     * @returns A JSON object with the following keys:
     * compID: the unique ID associated with this component,
     * unsubscribeFn: the function to be called when the component needs to unsubscribe from the store,
     * validateMessage: any validation/error message that gets generated for this object,
     * actions: any actions that are defined for this object
     */
    registerAndSubscribeComponent(inComp: any, inCallback?: Function | null): AngularPConnectData;
    addFormField(inComp: any): void;
    removeFormField(inComp: any): void;
    /**
     * Returns **true** if the component's entry in ___componentPropsArr___ is
     * the same as the properties that are current associated with the component (___inComp___) passed in.
     * As a side effect, the component's entry in ___componentPropsArr___ is updated.
     * **Note**: It is assumed that the incoming component has the following:
     * (a) a bridgeComponentID _string_ property used as lookup key in ___componentPropsArr___
     * and (b) a ___pConn$___ property used to access functions called in ___getComponentProps___
     *
     * @param inComp The component asking if it should update itself
     * @returns Return **true**: means the component props are different and the component should update itself (re-render).
     * Return **false**: means the component props are the same and the component doesn't need to update (re-render).
     * If the ***inComp*** input is bad, false is also returned.
     */
    shouldComponentUpdate(inComp: any): boolean;
    isPageMessagesEmpty(incomingProps: any): any;
    /**
     * Can be called when the component has encountered a change event
     * @param inComp The component calling the change event
     * @param event The event
     */
    changeHandler(inComp: any, event: any): void;
    /**
     * Can be called when the component has encountered an event (such as blur)
     * @param inComp The component calling the event
     * @param event The event
     */
    eventHandler(inComp: any, event: any): void;
    /**
     * @returns A handle to the application's store
     */
    getStore(): any;
    /**
     * @param bLogMsg If true, will write the stringified state to the store for debugging/inspection
     * @param inComp If supplied, the component that is requesting the store's state
     * @returns A handle to the __state__ of application's store
     */
    getState(bLogMsg?: boolean, inComp?: any): object;
    /**
     *  processActions exposes all actions in the metadata.
     *  Attaches common handler (eventHandler) for all actions.
     */
    private processActions;
    static ɵfac: i0.ɵɵFactoryDeclaration<AngularPConnectService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AngularPConnectService>;
}

declare class FieldBase implements OnInit, OnDestroy {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    protected angularPConnect: AngularPConnectService;
    protected utils: Utils;
    protected angularPConnectData: AngularPConnectData;
    fieldControl: FormControl<any>;
    controlName$: string;
    actionsApi: object;
    propName: string;
    bHasForm$: boolean;
    testId: string;
    helperText: string;
    placeholder: string;
    value$: any;
    label$: string;
    hideLabel: boolean;
    bRequired$: boolean;
    bReadonly$: boolean;
    bDisabled$: boolean;
    bVisible$: boolean;
    displayMode$: string;
    /**
     * Initializes the component, registers with AngularPConnect, and sets up form control.
     */
    ngOnInit(): void;
    /**
     * Cleans up the component by removing it from the form group and unsubscribing from any observables.
     */
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    /**
     * Updates the component's common properties based on the provided configuration.
     *
     * @param configProps The configuration properties to update.
     */
    protected updateComponentCommonProperties(configProps: any): void;
    /**
     * Displays the validation message if it exists.
     */
    private displayValidationMessage;
    /**
     * Retrieves the error message for the current field control.
     *
     * @returns The error message, or an empty string if no error is found.
     */
    getErrorMessage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FieldBase, never, never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DatapageService {
    private http;
    private scService;
    constructor(http: HttpClient, scService: ServerConfigService);
    dataPageUrl: string;
    getDataPage(id: any, dpParams: any): rxjs.Observable<_angular_common_http.HttpResponse<Object>>;
    getResults(response: any): any;
    getDataPageData(dataPageName: any, parameters: any, context: any): Promise<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatapageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DatapageService>;
}

interface PConnFieldProps {
    label: string;
    required: boolean;
    disabled: boolean;
    value?: string;
    validatemessage: string;
    status?: string;
    onChange: any;
    onBlur?: any;
    readOnly: boolean;
    testId: string;
    helperText: string;
    displayMode?: string;
    hideLabel: boolean;
    placeholder?: string;
    visibility?: boolean;
}

interface IOption$2 {
    key: string;
    value: string;
}
interface AutoCompleteProps extends PConnFieldProps {
    deferDatasource?: boolean;
    datasourceMetadata?: any;
    onRecordChange?: any;
    additionalProps?: object;
    listType: string;
    parameters?: any;
    datasource: any;
    columns: any[];
}
declare class AutoCompleteComponent extends FieldBase implements OnInit {
    protected dataPageService: DatapageService;
    onRecordChange: EventEmitter<any>;
    configProps$: AutoCompleteProps;
    options$: any[];
    listType: string;
    columns: never[];
    parameters: {};
    filteredOptions: Observable<any[]>;
    filterValue: string;
    ngOnInit(): Promise<void>;
    setOptions(options: IOption$2[]): void;
    private _filter;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): Promise<void>;
    generateColumnsAndDataSource(): {
        columns: any[];
        datasource: any;
    };
    fillOptions(results: any): void;
    flattenParameters(params?: {}): {};
    getDisplayFieldsMetaData(columnList: any): any;
    preProcessColumns(columnList: any): any;
    fieldOnChange(event: Event): void;
    optionChanged(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutoCompleteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AutoCompleteComponent, "app-auto-complete", never, {}, { "onRecordChange": "onRecordChange"; }, never, never, true, never>;
}

declare class CancelAlertComponent implements OnChanges {
    private psService;
    pConn$: typeof PConnect;
    bShowAlert$: boolean;
    onAlertState$: EventEmitter<boolean>;
    itemKey: string;
    localizedVal: Function;
    localeCategory: string;
    discardButton: any;
    goBackButton: any;
    constructor(psService: ProgressSpinnerService);
    ngOnChanges(): void;
    dismissAlertOnly(): void;
    dismissAlert(): void;
    sendMessage(sMessage: string): void;
    createCancelAlertButtons(): void;
    buttonClick({ action }: {
        action: any;
    }): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CancelAlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CancelAlertComponent, "app-cancel-alert", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "bShowAlert$": { "alias": "bShowAlert$"; "required": false; }; }, { "onAlertState$": "onAlertState$"; }, never, never, true, never>;
}

interface CheckboxProps extends Omit<PConnFieldProps, 'value'> {
    value: boolean;
    caption?: string;
    trueLabel?: string;
    falseLabel?: string;
    selectionMode?: string;
    datasource?: any;
    selectionKey?: string;
    selectionList?: any;
    primaryField: string;
    readonlyContextList: any;
    referenceList: string;
    variant?: string;
    renderMode: string;
}
declare class CheckBoxComponent extends FieldBase implements OnInit, OnDestroy {
    configProps$: CheckboxProps;
    caption$?: string;
    showLabel$: boolean;
    isChecked$: boolean;
    trueLabel$?: string;
    falseLabel$?: string;
    selectionMode?: string;
    datasource?: any;
    selectionKey?: string;
    selectionList?: any;
    primaryField: string;
    selectedvalues: any;
    referenceList: string;
    listOfCheckboxes: any[];
    variant?: string;
    ngOnInit(): void;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    handleChangeMultiMode(event: any, element: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckBoxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckBoxComponent, "app-check-box", never, {}, {}, never, never, true, never>;
}

interface CurrrencyProps extends PConnFieldProps {
    currencyISOCode?: string;
    allowDecimals: boolean;
    formatter?: string;
}
declare class CurrencyComponent extends FieldBase {
    configProps$: CurrrencyProps;
    fieldControl: FormControl<number | null>;
    currencyOptions: object;
    currencySymbol: string;
    thousandSeparator: string;
    decimalSeparator: string;
    decimalPrecision: number | undefined;
    formattedValue: string;
    formatter: any;
    inputMode: NgxCurrencyInputMode;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    /**
     * Updates the currency properties
     *
     * @param {Object} configProps - Configuration properties.
     * @param {boolean} configProps.allowDecimals - Whether to allow decimal values.
     * @param {string} configProps.currencyISOCode - The ISO code of the currency.
     * @param {string} configProps.formatter - The formatter type (e.g., 'currency').
     */
    protected updateCurrencyProperties(configProps: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CurrencyComponent, "app-currency", never, {}, {}, never, never, true, never>;
}

interface DateTimeProps extends PConnFieldProps {
}
declare class DateTimeComponent extends FieldBase implements OnInit, OnDestroy {
    configProps$: DateTimeProps;
    stepHour: number;
    stepMinute: number;
    stepSecond: number;
    color: string;
    formattedValue$: any;
    theDateFormat: {
        dateFormatString: string;
        dateFormatStringLong: string;
        dateFormatStringLC: string;
        dateFormatMask: string;
    };
    timezone: string | undefined;
    placeholder: string;
    private sso;
    scrollStrategy: _angular_cdk_overlay.RepositionScrollStrategy;
    ngOnInit(): void;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    generateDateTime(sVal: any): string;
    fieldOnDateChange(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateTimeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateTimeComponent, "app-date-time", never, {}, {}, never, never, true, never>;
}

interface DateProps extends PConnFieldProps {
}
declare class DateComponent extends FieldBase implements OnInit, OnDestroy {
    configProps$: DateProps;
    theDateFormat: {
        dateFormatString: string;
        dateFormatStringLong: string;
        dateFormatStringLC: string;
        dateFormatMask: string;
    };
    formattedValue$: any;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnDateChange(event: any): void;
    hasErrors(): boolean;
    getErrorMessage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateComponent, "app-date", never, {}, {}, never, never, true, never>;
}

interface DecimalProps extends PConnFieldProps {
    currencyISOCode?: string;
    decimalPrecision?: number;
    showGroupSeparators?: string;
    formatter?: string;
}
declare class DecimalComponent extends FieldBase {
    configProps$: DecimalProps;
    fieldControl: FormControl<number | null>;
    decimalSeparator: string;
    thousandSeparator: string;
    currencySymbol: string;
    decimalPrecision: number | undefined;
    formatter: any;
    formattedValue: any;
    inputMode: any;
    suffix: string;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    /**
     * Updates decimal properties based on the provided configuration.
     *
     * @param {Object} configProps - Configuration properties.
     * @param {string} configProps.currencyISOCode - ISO code of the currency.
     * @param {string} configProps.formatter - Formatter type (e.g., 'decimal', 'currency').
     * @param {boolean} configProps.showGroupSeparators - Whether to show group separators.
     */
    protected updateDecimalProperties(configProps: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DecimalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DecimalComponent, "app-decimal", never, {}, {}, never, never, true, never>;
}

interface IOption$1 {
    key: string;
    value: string;
}
interface DropdownProps extends PConnFieldProps {
    datasource?: any[];
    onRecordChange?: any;
    fieldMetadata?: any;
    listType?: string;
    columns?: any[];
    deferDatasource?: boolean;
    datasourceMetadata?: any;
    parameters?: any;
}
declare class DropdownComponent extends FieldBase implements OnInit, OnDestroy {
    onRecordChange: EventEmitter<any>;
    configProps$: DropdownProps;
    options$: IOption$1[];
    theDatasource: any[] | null;
    localeContext: string;
    localeClass: string;
    localeName: string;
    localePath: string;
    localizedValue: string;
    set options(options: IOption$1[]);
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    /**
     * Updates dropdown properties based on the provided configuration.
     * @param configProps - Configuration properties
     */
    updateDropdownProperties(configProps: any): void;
    getDatapageData(): void;
    getData(dataSource: any, parameters: any, columns: any, context: any, listType: any): void;
    isSelected(buttonValue: string): boolean;
    fieldOnChange(event: any): void;
    getLocalizedOptionValue(opt: IOption$1): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DropdownComponent, "app-dropdown", never, {}, { "onRecordChange": "onRecordChange"; }, never, never, true, never>;
}

interface EmailProps extends PConnFieldProps {
}
declare class EmailComponent extends FieldBase implements OnInit, OnDestroy {
    configProps$: EmailProps;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EmailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EmailComponent, "app-email", never, {}, {}, never, never, true, never>;
}

interface IntegerProps extends PConnFieldProps {
}
declare class IntegerComponent extends FieldBase {
    configProps$: IntegerProps;
    fieldControl: FormControl<number | null>;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IntegerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IntegerComponent, "app-integer", never, {}, {}, never, never, true, never>;
}

interface ObjectReferenceProps extends PConnFieldProps {
    showPromotedFilters: boolean;
    inline: boolean;
    parameters: object;
    mode: string;
    targetObjectType: any;
    allowAndPersistChangesInReviewMode: boolean;
}
declare class ObjectReferenceComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    configProps: ObjectReferenceProps;
    value: {
        [key: string]: any;
    };
    readOnly: boolean;
    isForm: boolean;
    type: string;
    isDisplayModeEnabled: boolean;
    canBeChangedInReviewMode: boolean;
    newComponentName: string;
    newPconn: typeof PConnect;
    rawViewMetadata: ComponentMetadataConfig | undefined;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    onStateChange(): void;
    ngOnDestroy(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    onRecordChange(value: any): void;
    private getComponentType;
    private createSemanticLinkPConnect;
    private createOtherComponentPConnect;
    static ɵfac: i0.ɵɵFactoryDeclaration<ObjectReferenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ObjectReferenceComponent, "app-object-reference", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface PercentageProps extends Omit<PConnFieldProps, 'value'> {
    value?: number;
    showGroupSeparators?: string;
    decimalPrecision?: number;
    currencyISOCode?: string;
}
declare class PercentageComponent extends FieldBase {
    configProps$: PercentageProps;
    fieldControl: FormControl<number | null>;
    decimalSeparator: string;
    thousandSeparator: string;
    inputMode: any;
    decimalPrecision: number | undefined;
    formattedValue: string;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    /**
     * Updates the percentage properties
     *
     * @param {Object} configProps - Configuration properties.
     * @param {boolean} configProps.showGroupSeparators - Whether to show group separators.
     * @param {number} configProps.decimalPrecision - The number of decimal places to display.
     */
    updatePercentageProperties(configProps: any): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PercentageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PercentageComponent, "app-percentage", never, {}, {}, never, never, true, never>;
}

interface PhoneProps extends PConnFieldProps {
}
declare class PhoneComponent extends FieldBase {
    configProps$: PhoneProps;
    preferredCountries: string[];
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnBlur(): void;
    fieldOnChange(): void;
    updatePreferredCountries(): void;
    getErrorMessage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PhoneComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PhoneComponent, "app-phone", never, {}, {}, never, never, true, never>;
}

interface IOption {
    key: string;
    value: string;
}
interface RadioButtonsProps extends PConnFieldProps {
    inline: boolean;
    fieldMetadata?: any;
    variant?: string;
}
declare class RadioButtonsComponent extends FieldBase {
    configProps$: RadioButtonsProps;
    bInline$: boolean;
    options$: IOption[];
    componentReference: string;
    fieldMetadata: any[];
    localeContext: string;
    localeClass: string;
    localeName: string;
    localePath: string;
    localizedValue: string;
    variant?: string;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    /**
     * Updates radio buttons properties based on the provided config props.
     * @param configProps Configuration properties.
     */
    protected updateRadioButtonsProperties(configProps: any): void;
    isSelected(buttonValue: string): boolean;
    fieldOnChange(event: any): void;
    getLocalizedOptionValue(opt: IOption): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonsComponent, "app-radio-buttons", never, {}, {}, never, never, true, never>;
}

interface RichTextProps extends PConnFieldProps {
}
declare class RichTextComponent extends FieldBase {
    configProps$: RichTextProps;
    info: any;
    error: boolean;
    status: any;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(editorValue: any): void;
    fieldOnBlur(editorValue: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RichTextComponent, "app-rich-text", never, {}, {}, never, never, true, never>;
}

interface SemanticLinkProps extends PConnFieldProps {
    text: string;
    resourcePayload: any;
    resourceParams: any;
    previewKey: string;
    referenceType: string;
    dataRelationshipContext: string;
    contextPage: any;
}
declare class SemanticLinkComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    configProps$: SemanticLinkProps;
    label$: string;
    value$: string;
    displayMode$?: string;
    bVisible$: boolean;
    linkURL: string;
    dataResourcePayLoad: any;
    referenceType: string;
    shouldTreatAsDataReference: boolean;
    previewKey: string;
    resourcePayload: any;
    payload: object;
    dataViewName: string;
    isLinkTextEmpty: boolean;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    showDataAction(): void;
    openLinkClick(e: any): void;
    private initializeComponentState;
    private buildDataPayload;
    private buildLinkURL;
    static ɵfac: i0.ɵɵFactoryDeclaration<SemanticLinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SemanticLinkComponent, "app-semantic-link", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface TextProps extends PConnFieldProps {
}
declare class TextComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    formatAs$: string;
    angularPConnectData: AngularPConnectData;
    configProps$: TextProps;
    label$: string;
    value$: string;
    bRequired$: boolean;
    bReadonly$: boolean;
    bDisabled$: boolean;
    bVisible$: boolean;
    displayMode$?: string;
    controlName$: string;
    componentReference: string;
    formattedValue$: string;
    format$: string;
    formattedUrl$: string;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    onStateChange(): void;
    generateUrl(sVal: any): string;
    generateDate(sVal: any): string;
    generateDateTime(sVal: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextComponent, "app-text", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "formatAs$": { "alias": "formatAs$"; "required": false; }; }, {}, never, never, true, never>;
}

interface TextAreaProps extends PConnFieldProps {
    fieldMetadata?: any;
}
declare class TextAreaComponent extends FieldBase {
    configProps$: TextAreaProps;
    nMaxLength$: number;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextAreaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextAreaComponent, "app-text-area", never, {}, {}, never, never, true, never>;
}

interface TextContentProps extends PConnFieldProps {
    content: string;
    displayAs: 'Paragraph' | 'Heading 1' | 'Heading 2' | 'Heading 3' | 'Heading 4';
}
declare class TextContentComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    angularPConnectData: AngularPConnectData;
    configProps$: TextContentProps;
    content$: string;
    displayAs$: string;
    displayMode$?: string;
    bVisible$: boolean;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    updateSelf(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextContentComponent, "app-text-content", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

interface TextInputProps extends PConnFieldProps {
    fieldMetadata?: any;
}
declare class TextInputComponent extends FieldBase {
    configProps$: TextInputProps;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TextInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TextInputComponent, "app-text-input", never, {}, {}, never, never, true, never>;
}

interface TimeProps extends PConnFieldProps {
}
declare class TimeComponent extends FieldBase {
    configProps$: TimeProps;
    formattedValue$: any;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimeComponent, "app-time", never, {}, {}, never, never, true, never>;
}

interface URLProps extends PConnFieldProps {
}
declare class UrlComponent extends FieldBase {
    configProps$: URLProps;
    /**
     * Updates the component when there are changes in the state.
     */
    updateSelf(): void;
    fieldOnChange(event: any): void;
    fieldOnBlur(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UrlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UrlComponent, "app-url", never, {}, {}, never, never, true, never>;
}

declare class UserReferenceComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    controlName$: string;
    value$: any;
    userName$: string;
    label$: string;
    userID$: string;
    options$: any;
    bReadonly$: boolean;
    bRequired$: boolean;
    showAsFormattedText$?: boolean;
    displayAs$?: string;
    testId: string;
    helperText: string;
    placeholder: string;
    displayMode$?: string;
    filteredOptions: Observable<any[]>;
    filterValue: string;
    fieldControl: FormControl<string | null>;
    actionsApi: object;
    propName: string;
    onRecordChange: any;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): Promise<void>;
    ngOnDestroy(): void;
    get type(): string;
    onStateChange(): Promise<void>;
    private _filter;
    isUserNameAvailable: (user: any) => any;
    getUserName: (user: any) => any;
    getValue: (user: any) => any;
    checkAndUpdate(): Promise<void>;
    updateSelf(): Promise<void>;
    fieldOnChange(event: any): void;
    optionChanged(event: any): void;
    fieldOnBlur(event: any): void;
    getErrorMessage(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserReferenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserReferenceComponent, "app-user-reference", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ActionButtonsComponent {
    arMainButtons$: any[];
    arSecondaryButtons$: any[];
    actionButtonClick: EventEmitter<any>;
    localizedVal: (localeKey: string, localePath?: string, localeRuleKey?: string | null, componentName?: string | null) => string;
    localeCategory: string;
    buttonClick(sAction: any, sButtonType: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActionButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActionButtonsComponent, "app-action-buttons", never, { "arMainButtons$": { "alias": "arMainButtons$"; "required": false; }; "arSecondaryButtons$": { "alias": "arSecondaryButtons$"; "required": false; }; }, { "actionButtonClick": "actionButtonClick"; }, never, never, true, never>;
}

declare class BannerService {
    banners: any[];
    clearBanners(): void;
    updateBanners(itemKey: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BannerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BannerService>;
}

interface AssignmentProps {
    template: string;
}
declare class AssignmentComponent implements OnInit, OnDestroy, OnChanges {
    private angularPConnect;
    private psService;
    private erService;
    private snackBar;
    bannerService: BannerService;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    itemKey$: string;
    isCreateStage$: boolean;
    updateToken$: number;
    isInModal$: boolean;
    angularPConnectData: AngularPConnectData;
    configProps$: AssignmentProps;
    newPConn$: any;
    containerName$: string;
    bInitialized: boolean;
    templateName$: string;
    arMainButtons$: any[];
    arSecondaryButtons$: any[];
    actionsAPI: any;
    bHasNavigation$: boolean;
    bIsVertical$: boolean;
    prevNavigationSteps: any[];
    arCurrentStepIndicies$: number[];
    arNavigationSteps$: any[];
    init: boolean;
    finishAssignment: any;
    navigateToStep: any;
    saveAssignment: any;
    cancelAssignment: any;
    cancelCreateStageAssignment: any;
    showPage: any;
    approveCase: any;
    rejectCase: any;
    bReInit: boolean;
    localizedVal: any;
    localeCategory: string;
    localeReference: any;
    snackBarRef: any;
    constructor(angularPConnect: AngularPConnectService, psService: ProgressSpinnerService, erService: ErrorMessagesService, snackBar: MatSnackBar, bannerService: BannerService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    ngOnChanges(): void;
    updateChanges(): void;
    initComponent(): void;
    createButtons(): void;
    createButtonsForMultiStepForm(oCaseInfo: any): void;
    findCurrentIndicies(arStepperSteps: any[], arIndicies: number[], depth: number): number[];
    onSaveActionSuccess(data: any): void;
    onActionButtonClick(oData: any): void;
    buttonClick(sAction: any, sButtonType: any): void;
    formValid(): boolean;
    touchAll(): void;
    topViewRefresh(): void;
    registerForRefresh(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AssignmentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AssignmentComponent, "app-assignment", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "arChildren$": { "alias": "arChildren$"; "required": false; }; "itemKey$": { "alias": "itemKey$"; "required": false; }; "isCreateStage$": { "alias": "isCreateStage$"; "required": false; }; "updateToken$": { "alias": "updateToken$"; "required": false; }; "isInModal$": { "alias": "isInModal$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AssignmentCardComponent implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arMainButtons$: any[];
    arSecondaryButtons$: any[];
    arChildren$: any[];
    updateToken$: number;
    childrenArray: any[];
    actionButtonClick: EventEmitter<any>;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onActionButtonClick(oData: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AssignmentCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AssignmentCardComponent, "app-assignment-card", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "arMainButtons$": { "alias": "arMainButtons$"; "required": false; }; "arSecondaryButtons$": { "alias": "arSecondaryButtons$"; "required": false; }; "arChildren$": { "alias": "arChildren$"; "required": false; }; "updateToken$": { "alias": "updateToken$"; "required": false; }; }, { "actionButtonClick": "actionButtonClick"; }, never, never, true, never>;
}

declare class FlowContainerBaseComponent {
    protected angularPConnectData: AngularPConnectData;
    protected angularPConnect: any;
    constructor(injector: Injector);
    getPConnectOfActiveContainerItem(parentPConnect: any): _pega_pcore_pconnect_typedefs_interpreter_c11n_env.C11nEnv | null;
}

/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
interface FlowContainerProps {
    children?: any[];
    name?: string;
    routingInfo?: any;
    pageMessages: any[];
}
declare class FlowContainerComponent extends FlowContainerBaseComponent implements OnInit, OnDestroy {
    private cdRef;
    private psService;
    private fb;
    private ngZone;
    private utils;
    pConn$: typeof PConnect;
    pCoreConstants: typeof publicConstants;
    configProps$: FlowContainerProps;
    formGroup$: FormGroup;
    arChildren$: any[];
    itemKey$: string;
    containerName$: string;
    buildName$: string;
    todo_showTodo$: boolean;
    todo_caseInfoID$: string;
    todo_showTodoList$: boolean;
    todo_datasource$: any;
    todo_headerText$: string;
    todo_type$: string;
    todo_context$: string;
    todo_pConn$: typeof PConnect;
    bHasCancel: boolean;
    caseMessages$: string;
    bHasCaseMessages$: boolean;
    checkSvg$: string;
    TODO: any;
    bShowConfirm: boolean;
    bShowBanner: boolean;
    confirm_pconn: any;
    localizedVal: any;
    localeCategory: string;
    localeReference: any;
    banners: any[];
    pConnectOfActiveContainerItem: any;
    isMultiStep: any;
    constructor(injector: Injector, cdRef: ChangeDetectorRef, psService: ProgressSpinnerService, fb: FormBuilder, ngZone: NgZone, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    handleCancel(): void;
    handleCancelPressed(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    showPageMessages(completeProps: FlowContainerProps): void;
    getTodoVisibilty(): boolean;
    initContainer(): void;
    initComponent(bLoadChildren: boolean): void;
    isCaseWideLocalAction(): boolean;
    hasChildCaseAssignments(): any;
    getActiveViewLabel(): string;
    findCurrentIndicies(arStepperSteps: any[], arIndicies: number[], depth: number): number[];
    updateSelf(): void;
    loadReviewPage(localPConn: any): void;
    showCaseMessages(): void;
    updateFlowContainerChildren(): void;
    addPConnectAndUpdateChildren(currentItem: any, key: any): void;
    getBuildName(): string;
    formValid(): boolean;
    touchAll(): void;
    topViewRefresh(): void;
    addContainerItem(pConnect: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlowContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FlowContainerComponent, "app-flow-container", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare function hasAssignments(pConnect: any): any;
declare const showBanner: (getPConnect: any) => boolean;
declare function getToDoAssignments(pConnect: any): any;

/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
declare class HybridViewContainerComponent {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    displayOnlyFA$: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<HybridViewContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HybridViewContainerComponent, "app-hybrid-view-container", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "displayOnlyFA$": { "alias": "displayOnlyFA$"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
declare class ModalViewContainerComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private ngZone;
    private psService;
    private fb;
    pConn$: typeof PConnect;
    modalVisibleChange: EventEmitter<boolean>;
    angularPConnectData: AngularPConnectData;
    arChildren$: any[];
    stateProps$: object;
    banners: any;
    templateName$: string;
    buildName$: string;
    context$: string;
    title$: string;
    bShowModal$: boolean;
    itemKey$: string;
    formGroup$: FormGroup;
    oCaseInfo: object;
    updateToken$: number;
    routingInfoRef: any;
    createdViewPConn$: any;
    bSubscribed: boolean;
    cancelPConn$?: typeof PConnect;
    bShowCancelAlert$: boolean;
    bAlertState: boolean;
    localizedVal: Function;
    localeCategory: string;
    isMultiRecord: boolean;
    actionsDialog: boolean;
    constructor(angularPConnect: AngularPConnectService, ngZone: NgZone, psService: ProgressSpinnerService, fb: FormBuilder);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    updateSelf(): void;
    createView(routingInfo: any, currentItem: any, latestItem: any, key: any): void;
    hideModal(): void;
    getConfigObject(item: any, pConnect: any, isReverseCoexistence?: boolean): _pega_pcore_pconnect_typedefs_interpreter_types.CreateC11nEnv | null;
    checkIfRefComponent(thePConn: any): boolean;
    onAlertState(bData: boolean): void;
    showAlert(payload: any): void;
    hasContainerItems(routingInfo: any): any;
    getKeyAndLatestItem(routinginfo: any): {
        key: any;
        latestItem: any;
    } | {
        key?: undefined;
        latestItem?: undefined;
    };
    compareCaseInfoIsDifferent(oCurrentCaseInfo: object): boolean;
    getBanners(): any;
    getModalHeading(dataObjectAction: any): any;
    determineModalHeaderByAction(actionName: any, caseTypeName: any, ID: any, caseLocaleRef: any): any;
    closeActionsDialog: () => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalViewContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ModalViewContainerComponent, "app-modal-view-container", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, { "modalVisibleChange": "modalVisibleChange"; }, never, never, true, never>;
}

/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
declare class PreviewViewContainerComponent implements OnInit {
    pConn$: typeof PConnect;
    ngOnInit(): void;
    buildName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PreviewViewContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PreviewViewContainerComponent, "app-preview-view-container", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
interface ViewContainerProps {
    mode?: string;
    name?: string;
    limit?: number;
    template?: string;
    title?: string;
    routingInfo: object;
    readOnly?: boolean;
}
declare class ViewContainerComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private psService;
    private ngZone;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    displayOnlyFA$: boolean;
    angularPConnectData: AngularPConnectData;
    configProps$: ViewContainerProps;
    arChildren$: any[];
    templateName$: string;
    buildName$: string;
    context$: string;
    title$: string;
    viewPConn$: any;
    isViewContainer$: boolean;
    createdViewPConn$: any;
    state: any;
    dispatchObject: any;
    constructor(angularPConnect: AngularPConnectService, psService: ProgressSpinnerService, ngZone: NgZone);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    prepareDispatchObject(): any;
    buildName(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewContainerComponent, "app-view-container", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "displayOnlyFA$": { "alias": "displayOnlyFA$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DashboardFilterComponent implements OnInit {
    pConn$: typeof PConnect;
    filtersFormGroup$: FormGroup;
    inlineProps: any;
    children: any;
    arChildren$: any[];
    private filterChangeSubject;
    constructor();
    ngOnInit(): void;
    clearFilters(): void;
    updateTmpData(filterData: any): void;
    dateRangeChangeHandler(field: any): void;
    fireFilterChange(data: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardFilterComponent, "app-dashboard-filter", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "filtersFormGroup$": { "alias": "filtersFormGroup$"; "required": false; }; "inlineProps": { "alias": "inlineProps"; "required": false; }; "children": { "alias": "children"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
declare class DeferLoadComponent implements OnInit, OnDestroy, OnChanges {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: any;
    name: any;
    childComponentPConnect: typeof PConnect;
    bShowDefer$: boolean;
    angularPConnectData: AngularPConnectData;
    constants: typeof publicConstants;
    currentLoadedAssignment: string;
    isContainerPreview: boolean;
    loadViewCaseID: any;
    resourceType: any;
    deferLoadId: any;
    containerName: any;
    CASE: any;
    PAGE: any;
    DATA: any;
    lastUpdateCaseTime: any;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    getViewOptions: () => {
        viewContext: any;
        pageClass: any;
        container: string | undefined;
        containerName: string | undefined;
        updateData: boolean;
    };
    onResponse(data: any): void;
    loadActiveTab(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeferLoadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeferLoadComponent, "app-defer-load", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ErrorBoundaryComponent {
    message: string;
    localizedVal: (localeKey: string, localePath?: string, localeRuleKey?: string | null, componentName?: string | null) => string;
    localeCategory: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorBoundaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorBoundaryComponent, "app-error-boundary", never, { "message": { "alias": "message"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MultiStepComponent implements OnInit {
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arMainButtons$: any[];
    arSecondaryButtons$: any[];
    arChildren$: any[];
    bIsVertical$: boolean;
    arCurrentStepIndicies$: number[];
    arNavigationSteps$: any[];
    actionButtonClick: EventEmitter<any>;
    svgCurrent$: string;
    svgNotCurrent$: string;
    bShow$: boolean;
    constructor(utils: Utils);
    ngOnInit(): void;
    onActionButtonClick(oData: any): void;
    _getVIconClass(status: any): string;
    _getVLabelClass(status: any): string;
    _getVBodyClass(index: number): string;
    _getHIconClass(status: any): string;
    _getHLabelClass(status: any): string;
    _showHLine(index: number): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiStepComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiStepComponent, "app-multi-step", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "arMainButtons$": { "alias": "arMainButtons$"; "required": false; }; "arSecondaryButtons$": { "alias": "arSecondaryButtons$"; "required": false; }; "arChildren$": { "alias": "arChildren$"; "required": false; }; "bIsVertical$": { "alias": "bIsVertical$"; "required": false; }; "arCurrentStepIndicies$": { "alias": "arCurrentStepIndicies$"; "required": false; }; "arNavigationSteps$": { "alias": "arNavigationSteps$"; "required": false; }; }, { "actionButtonClick": "actionButtonClick"; }, never, never, true, never>;
}

interface NavBarProps {
    showAppName?: boolean;
}
declare class NavbarComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private chRef;
    private psService;
    private ngZone;
    private utils;
    pConn$: typeof PConnect;
    appName$: string;
    pages$: any[];
    caseTypes$: any[];
    angularPConnectData: AngularPConnectData;
    configProps$: NavBarProps;
    navPages$: any[];
    navExpandCollapse$: string;
    bShowCaseTypes$: boolean;
    portalApp$: string | undefined;
    portalLogoImage$: string;
    showAppName$?: boolean;
    portalOperator$: string | undefined;
    portalOperatorInitials$: string;
    actionsAPI: any;
    createWork: any;
    showPage: any;
    logout: any;
    navIcon$: string;
    localizedVal: any;
    localeCategory: string;
    localeUtils: _pega_pcore_pconnect_typedefs_locale_locale_utils.LocaleUtils;
    constructor(angularPConnect: AngularPConnectService, chRef: ChangeDetectorRef, psService: ProgressSpinnerService, ngZone: NgZone, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    loadImage(src: string): Promise<unknown>;
    onStateChange(): void;
    updateSelf(): void;
    initComponent(): void;
    navPanelButtonClick(oPageData: any): void;
    navPanelCreateButtonClick(): void;
    navPanelCreateCaseType(sCaseType: string, sFlowType: string): void;
    navPanelLogoutClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavbarComponent, "app-navbar", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "appName$": { "alias": "appName$"; "required": false; }; "pages$": { "alias": "pages$"; "required": false; }; "caseTypes$": { "alias": "caseTypes$"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
declare class ReferenceComponent {
    private static bLogging;
    /**
     * Creates a normalized PConn from a reference component.
     * Resolves the reference to its fully realized View with proper configuration.
     *
     * @param inPConn - The PConn object that represents a reference component
     * @returns The dereferenced PConnect object, or null if reference can't be resolved
     */
    static createFullReferencedViewFromRef(inPConn: any): any;
    /**
     * Normalizes a PConn object that might be a 'reference'.
     * If the incoming PConn is a reference, returns its dereferenced View.
     * Otherwise, returns the passed in PConn unchanged.
     *
     * @param inPConn - A PConn object (ex: { getPConnect() } or direct PConnect)
     * @returns The normalized PConn object with references resolved
     */
    static normalizePConn(inPConn: any): any;
    /**
     * Normalizes an array of PConn objects by replacing any 'reference' components
     * with their referenced views.
     *
     * @param inPConnArray - Array of PConn objects to normalize
     * @returns Normalized array with references resolved, or empty array if input is invalid
     */
    static normalizePConnArray(inPConnArray: any[]): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ReferenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReferenceComponent, "app-reference", never, {}, {}, never, never, true, never>;
}

declare class RegionComponent implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RegionComponent, "app-region", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class RootContainerComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private psService;
    private ngZone;
    pConn$: typeof PConnect;
    displayOnlyFA$: boolean;
    isMashup$: boolean;
    scService: ServerConfigService;
    angularPConnectData: AngularPConnectData;
    componentName$: string;
    bIsProgress$: boolean;
    pvConn$: any;
    mConn$: any;
    bShowRoot$: boolean;
    progressSpinnerSubscription: Subscription;
    spinnerTimer: any;
    viewContainerPConn$: any;
    localizedVal: any;
    localeCategory: string;
    constructor(angularPConnect: AngularPConnectService, psService: ProgressSpinnerService, ngZone: NgZone);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    updateSelf(): void;
    configureModalContainer(): Promise<void>;
    generateViewContainerForNoPortal(): void;
    showHideProgress(bShow: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RootContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RootContainerComponent, "app-root-container", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "displayOnlyFA$": { "alias": "displayOnlyFA$"; "required": false; }; "isMashup$": { "alias": "isMashup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface StagesProps {
    stages: any[];
}
declare class StagesComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    angularPConnectData: AngularPConnectData;
    PCore$: typeof PCore;
    configProps$: StagesProps;
    arStageResults$: any[];
    lastStage$: any;
    checkSvgIcon$: string;
    key: any;
    localizationService: any;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StagesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StagesComponent, "app-stages", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

interface ViewProps {
    template?: string;
    label?: string;
    showLabel: boolean;
    title?: string;
    visibility?: boolean;
}
declare class ViewComponent implements OnInit, OnDestroy, OnChanges {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    displayOnlyFA$: boolean;
    angularPConnectData: AngularPConnectData;
    noHeaderTemplates: string[];
    configProps$: ViewProps;
    inheritedProps$: any;
    arChildren$: any[];
    templateName$: string;
    title$: string;
    label$: string;
    showLabel$: boolean;
    visibility$: boolean;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    additionalProps(state: any, getPConnect: any): {};
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ViewComponent, "app-view", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "displayOnlyFA$": { "alias": "displayOnlyFA$"; "required": false; }; }, {}, never, never, true, never>;
}

declare function getMappedKey(key: any): any;
declare const getComponentStateOptions: (getPConnect: any) => {
    clearOnCancelForContext: any;
};
interface SearchCategory {
    selectedCategory: string;
}
interface SearchGroup {
    searchFields: unknown;
    activeGroupId: string;
}
declare const componentCachePersistUtils: {
    getComponentStateKey: (getPConnect: any, propertyName: string) => string;
    getComponentStateOptions: (getPConnect: any) => {
        clearOnCancelForContext: any;
    };
    setComponentCache: ({ cacheKey, state, options }: {
        cacheKey: string;
        state: SearchCategory | SearchGroup;
        options: ReturnType<typeof getComponentStateOptions>;
    }) => void;
};

declare function getCacheInfo(cache: {
    selectedCategory: string;
    activeGroupId: string;
    searchFields: unknown;
}, groups: {
    config: {
        id: string;
    };
}[]): {
    useCache: boolean;
    initialActiveGroupId: string;
};
declare function isValidInput(input: {
    [s: string]: unknown;
}): boolean;

interface IPage {
    classID: string;
    pxPageViewIcon: string;
    pyClassName: string;
    pyLabel: string;
    pyRuleName: string;
    pyURLContent: string;
}
interface AppShellProps {
    pages: IPage[];
    caseTypes?: object[];
    portalLogo: string;
    portalName: string;
    portalTemplate: string;
    readOnly?: boolean;
    showAppHeaderBar: boolean;
    showAppName: any;
}
declare class AppShellComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private erService;
    private snackBar;
    private ngZone;
    private utils;
    pConn$: typeof PConnect;
    angularPConnectData: AngularPConnectData;
    configProps$: AppShellProps;
    pages$: IPage[];
    caseTypes$?: object[];
    arChildren$: any[];
    bShowAppShell$: boolean;
    appName$: string;
    errorMessagesSubscription: Subscription;
    sErrorMessages: string;
    snackBarRef: any;
    bOkDisplayError: boolean;
    portalTemplate: string;
    links: any;
    imageURL: string | Blob;
    localizedVal: (localeKey: string, localePath?: string, localeRuleKey?: string | null, componentName?: string | null) => string;
    constructor(angularPConnect: AngularPConnectService, erService: ErrorMessagesService, snackBar: MatSnackBar, ngZone: NgZone, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    showDismissErrorMessages(errorMessages: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppShellComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppShellComponent, "app-app-shell", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FormTemplateBase implements OnDestroy {
    pConn$: any;
    angularPConnectData: AngularPConnectData;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormTemplateBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormTemplateBase, never, never, {}, {}, never, never, true, never>;
}

declare class DetailsTemplateBase implements OnInit, OnDestroy {
    pConn$: typeof PConnect;
    protected angularPConnectData: AngularPConnectData;
    protected angularPConnect: any;
    childrenMetadataOld: any;
    constructor(injector: Injector);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    hasRawMetadataChanged(): boolean;
    fetchChildrenMetadata(): {
        [key: string]: any;
    }[];
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsTemplateBase, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DetailsTemplateBase, never, never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

interface CaseSummaryProps {
    status?: string;
    showStatus?: boolean;
    template?: string;
    readOnly?: boolean;
}
declare class CaseSummaryComponent implements OnInit, OnDestroy, OnChanges {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    configProps$: CaseSummaryProps;
    arChildren$: any[];
    status$?: string;
    bShowStatus$?: boolean;
    primaryFields$: any[];
    secondaryFields$: any[];
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    initComponent(): void;
    onStateChange(): void;
    updateSelf(): void;
    ngOnChanges(): void;
    generatePrimaryAndSecondaryFields(): void;
    prepareCaseSummaryData(summaryFieldChildren: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseSummaryComponent, "app-case-summary", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface CaseViewProps {
    icon: string;
    subheader: string;
    header: string;
}
declare class CaseViewComponent implements OnInit, OnDestroy {
    private cdRef;
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    configProps$: CaseViewProps;
    arChildren$: any[];
    heading$: string;
    id$: string;
    status$: string;
    caseTabs$: any[];
    svgCase$: string;
    tabData$: any;
    mainTabs: any;
    mainTabData: any;
    arAvailableActions$: any[];
    arAvailabeProcesses$: any[];
    caseSummaryPConn$: any;
    currentCaseID: string;
    editAction: boolean;
    localizedVal: any;
    localeCategory: string;
    localeKey: string;
    constructor(cdRef: ChangeDetectorRef, angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    hasCaseIDChanged(): boolean;
    updateHeaderAndSummary(): void;
    fullUpdate(): void;
    generateTabsData(): void;
    updateSelf(): void;
    onTabClick(tab: any): void;
    _editClick(): void;
    _menuActionClick(data: any): void;
    _menuProcessClick(data: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseViewComponent, "app-case-view", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface ConfirmationProps {
    datasource: {
        source: any;
    };
    label: string;
    showLabel: boolean;
    showTasks: boolean;
}
declare class ConfirmationComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    angularPConnectData: AngularPConnectData;
    configProps$: ConfirmationProps;
    rootInfo: any;
    datasource: any;
    showTasks: any;
    detailProps: any;
    toDoList: any;
    label: string;
    CONSTS: typeof publicConstants;
    showDetails: boolean;
    showConfirmView: boolean;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    onConfirmViewClose(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationComponent, "app-confirmation", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DataReferenceAdvancedSearchService {
    private configSubject;
    config$: rxjs.Observable<null>;
    setConfig(config: any): void;
    getConfig(): null;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataReferenceAdvancedSearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DataReferenceAdvancedSearchService>;
}

declare class DataReferenceComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private advancedSearchService;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    arFields$: any[];
    referenceType: string;
    selectionMode: string;
    parameters: any;
    hideLabel: boolean;
    childrenToRender: any[];
    dropDownDataSource: string;
    isDisplayModeEnabled: boolean;
    propsToUse: any;
    rawViewMetadata: any;
    viewName: string;
    firstChildMeta: any;
    canBeChangedInReviewMode: boolean;
    propName: string;
    firstChildPConnect: any;
    children: any;
    displaySingleRef: boolean;
    displayMultiRef: boolean;
    refList: any;
    displayAs: any;
    isDDSourceDeferred: any;
    showPromotedFilters: any;
    displayMode: any;
    refFieldMetadata: any;
    contextClass: any;
    selectionList: any;
    inline: any;
    isCreationOfNewRecordAllowedForReference: any;
    showAdvancedSearch: boolean;
    pyID: any;
    allowImplicitRefresh: any;
    displayChild: boolean;
    dataRelationshipContext: any;
    imagePosition: any;
    showImageDescription: any;
    constructor(angularPConnect: AngularPConnectService, advancedSearchService: DataReferenceAdvancedSearchService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    updateSelf(): void;
    updatePropertiesFromProps(theConfigProps: any): void;
    generateChildrenToRender(): any;
    handleSelection(event: any): void;
    recreatedFirstChild(): any;
    private setReadOnlyDisplayFlags;
    private prepareFirstChildMeta;
    private setChildDatasource;
    private buildDataReferenceConfig;
    private buildFieldMetaData;
    private isCreateNewRecordEnabled;
    private getCreateNewRecordFn;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataReferenceComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataReferenceComponent, "app-data-reference", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare function getTabCountSources(deferLoadedTabs: any): any;
declare function getData(deferLoadedTabs: any, tabCountSources: any, currentTabId: any, data: any): any;

declare class SearchFormComponent implements OnInit, OnChanges {
    private dialog;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    searchSelectCacheKey: any;
    configProps$: any;
    isInitialized: boolean;
    currentTabId: string;
    nextTabId: string;
    openDialog: boolean;
    tabItems: any[];
    searchCategoriesComp: any;
    propsToUse: any;
    tabData: any;
    tabCountSources: any;
    deferLoadedTabs: any;
    dialogTemplate: TemplateRef<any>;
    dialogRef: any;
    constructor(dialog: MatDialog);
    ngOnInit(): void;
    ngOnChanges(): void;
    updateSelf(): void;
    initializeSearchCategories(): void;
    handleTabClick(event: any): void;
    clearSelectionAndSwitchTab(): void;
    onDialogClose(): void;
    publishEvent({ clearSelections, viewName }: {
        clearSelections: any;
        viewName: any;
    }): void;
    get activeTabPConnect(): any;
    checkIfSelectionsExist(getPConnect: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchFormComponent, "app-search-form", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "searchSelectCacheKey": { "alias": "searchSelectCacheKey"; "required": false; }; }, {}, never, never, true, never>;
}

declare function getFieldMeta(getPConnect: any, dataRelationshipContext: any): {
    compositeKeys: any;
    fieldMetadata: any;
};
declare const getFirstChildConfig: ({ firstChildMeta, getPConnect, rawViewMetadata, contextClass, dataReferenceConfigToChild, isCreateNewReferenceEnabled, disableStartingFieldsForReference, pyID }: {
    firstChildMeta: any;
    getPConnect: any;
    rawViewMetadata: any;
    contextClass: any;
    dataReferenceConfigToChild: any;
    isCreateNewReferenceEnabled: any;
    disableStartingFieldsForReference: any;
    pyID: any;
}) => any;

declare class TemplateUtils {
    /**
     * Determine if the current view is the view of the case step/assignment.
     * @param {Function} pConnect PConnect object for the component
     */
    getIsAssignmentView(pConnect: any): boolean;
    /**
     * A hook that gets the instructions content for a view.
     * @param {Function} pConnect PConnect object for the component
     * @param {string} [instructions="casestep"] 'casestep', 'none', or the html content of a Rule-UI-Paragraph rule (processed via core's paragraph annotation handler)
     */
    getInstructions(pConnect: any, instructions?: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TemplateUtils, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TemplateUtils>;
}

declare class DefaultFormComponent extends FormTemplateBase implements OnInit, OnChanges {
    private angularPConnect;
    private templateUtils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    arChildren$: any[];
    divClass$: string;
    instructions: string;
    constructor(angularPConnect: AngularPConnectService, templateUtils: TemplateUtils);
    ngOnInit(): void;
    onStateChange(): void;
    ngOnChanges(changes: any): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefaultFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DefaultFormComponent, "app-default-form", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class DetailsComponent extends DetailsTemplateBase {
    pConn$: typeof PConnect;
    highlightedDataArr: any[];
    showHighlightedData: boolean;
    arFields$: any[];
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailsComponent, "app-details", never, {}, {}, never, never, true, never>;
}

declare class DetailsNarrowWideComponent extends DetailsTemplateBase {
    pConn$: typeof PConnect;
    arFields$: any[];
    arFields2$: any[];
    highlightedDataArr: any[];
    showHighlightedData: boolean;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsNarrowWideComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailsNarrowWideComponent, "app-details-narrow-wide", never, {}, {}, never, never, true, never>;
}

declare class DetailsOneColumnComponent extends DetailsTemplateBase {
    pConn$: typeof PConnect;
    showHighlightedData: boolean;
    highlightedDataArr: any;
    arFields$: any[];
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsOneColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailsOneColumnComponent, "app-details-one-column", never, {}, {}, never, never, true, never>;
}

declare class DetailsSubTabsComponent extends DetailsTemplateBase {
    pConn$: typeof PConnect;
    currentTabId: string;
    tabItems: any[];
    availableTabs: any[];
    updateSelf(): void;
    updateTabContent(): void;
    handleTabClick(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsSubTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailsSubTabsComponent, "app-details-sub-tabs", never, {}, {}, never, never, true, never>;
}

declare class DetailsThreeColumnComponent extends DetailsTemplateBase {
    pConn$: typeof PConnect;
    showHighlightedData: boolean;
    highlightedDataArr: any;
    arFields$: any[];
    arFields2$: any[];
    arFields3$: any[];
    propsToUse: any;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsThreeColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailsThreeColumnComponent, "app-details-three-column", never, {}, {}, never, never, true, never>;
}

declare class DetailsTwoColumnComponent extends DetailsTemplateBase {
    pConn$: typeof PConnect;
    showHighlightedData: boolean;
    highlightedDataArr: any;
    arFields$: any[];
    arFields2$: any[];
    arFields3$: any[];
    propsToUse: any;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsTwoColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailsTwoColumnComponent, "app-details-two-column", never, {}, {}, never, never, true, never>;
}

declare class DetailsWideNarrowComponent extends DetailsTemplateBase {
    pConn$: typeof PConnect;
    highlightedDataArr: any[];
    showHighlightedData: boolean;
    arFields$: any[];
    arFields2$: any[];
    propsToUse: any;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DetailsWideNarrowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DetailsWideNarrowComponent, "app-details-wide-narrow", never, {}, {}, never, never, true, never>;
}

declare class FieldGroupListComponent {
    item: any;
    heading: any;
    formGroup$: any;
    fields: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldGroupListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldGroupListComponent, "app-field-group-list", never, { "item": { "alias": "item"; "required": false; }; "heading": { "alias": "heading"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface FieldGroupTemplateProps {
    label?: string;
    hideLabel?: boolean;
    allowActions?: any;
    allowRowDelete?: any;
    referenceList?: any[];
    contextClass: string;
    renderMode?: string;
    heading?: string;
    lookForChildInConfig?: boolean;
    displayMode?: string;
    fieldHeader?: string;
    allowTableEdit: boolean;
    targetClassLabel?: string;
}
declare class FieldGroupTemplateComponent implements OnInit, OnDestroy, OnChanges {
    private angularPConnect;
    private utils;
    configProps$: FieldGroupTemplateProps;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    showLabel$?: boolean;
    label$?: string;
    readonlyMode: boolean;
    contextClass: any;
    heading: any;
    children: any;
    menuIconOverride$: any;
    referenceListLength: i0.WritableSignal<number | null>;
    fieldHeader: any;
    allowAdd: i0.WritableSignal<boolean>;
    allowEdit: i0.WritableSignal<boolean>;
    allowDelete: boolean;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: any): void;
    updateSelf(): void;
    getStaticHeader: (heading: any, index: any) => string;
    getDynamicHeader: (item: any, index: any) => any;
    addFieldGroupItem(): void;
    deleteFieldGroupItem(index: any): void;
    getAddBtnLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldGroupTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldGroupTemplateComponent, "app-field-group-template", never, { "configProps$": { "alias": "configProps$"; "required": false; }; "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FieldValueListComponent {
    label$: any;
    value$: any;
    displayMode$: any;
    isHtml$: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldValueListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldValueListComponent, "app-field-value-list", never, { "label$": { "alias": "label$"; "required": false; }; "value$": { "alias": "value$"; "required": false; }; "displayMode$": { "alias": "displayMode$"; "required": false; }; "isHtml$": { "alias": "isHtml$"; "required": false; }; }, {}, never, never, true, never>;
}

interface InlineDashboardProps {
    title: string;
    filterPosition?: string;
}
declare class InlineDashboardComponent {
    pConn$: typeof PConnect;
    filtersFormGroup$: FormGroup;
    inlineProps: InlineDashboardProps;
    children: any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineDashboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InlineDashboardComponent, "app-inline-dashboard", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "filtersFormGroup$": { "alias": "filtersFormGroup$"; "required": false; }; "inlineProps": { "alias": "inlineProps"; "required": false; }; "children": { "alias": "children"; "required": false; }; }, {}, never, never, true, never>;
}

interface InlineDashboardPageProps {
    title: string;
    icon?: string;
    filterPosition?: string;
}
declare class InlineDashboardPageComponent implements OnInit, OnChanges {
    private fb;
    pConn$: typeof PConnect;
    configProps$: InlineDashboardPageProps;
    filterComponents: any;
    inlineProps: any;
    children: any;
    filtersFormGroup$: FormGroup;
    constructor(fb: FormBuilder);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InlineDashboardPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InlineDashboardPageComponent, "app-inline-dashboard-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ListPageComponent {
    pConn$: typeof PConnect;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListPageComponent, "app-list-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

interface ListViewProps {
    inheritedProps: any;
    title: string | undefined;
    globalSearch?: boolean;
    referenceList?: any;
    rowClickAction?: any;
    selectionMode?: string;
    referenceType?: string;
    compositeKeys?: any;
    showDynamicFields?: boolean;
    presets?: any;
    reorderFields: string | boolean;
    grouping: string | boolean;
    value: any;
    readonlyContextList: any;
    label?: string;
    displayAs?: string;
    showRecords: boolean;
    viewName?: string;
    localeReference?: any;
}
declare class Group$1 {
    level: number;
    parent: Group$1;
    expanded: boolean;
    totalCounts: number;
    get visible(): boolean;
}
declare class ListViewComponent implements OnInit, OnDestroy {
    private psService;
    utils: Utils;
    paginator: MatPaginator;
    sort: MatSort;
    pConn$: typeof PConnect;
    bInForm$: boolean;
    payload: any;
    repeatList$: MatTableDataSource<any>;
    selection: SelectionModel<any>;
    fields$: any[];
    displayedColumns$: any[];
    groupByColumns$: string[];
    configProps$: ListViewProps;
    updatedRefList: any;
    repeatListData: any[];
    searchIcon$: string;
    bShowSearch$: boolean;
    bColumnReorder$: boolean;
    bGrouping$: boolean;
    perfFilter: string;
    searchFilter: string;
    menuSvgIcon$: string;
    arrowSvgIcon$: string;
    arrowDownSvgIcon$: string;
    arrowUpSvgIcon$: string;
    filterSvgIcon$: string;
    filterOnSvgIcon$: string;
    groupBySvgIcon$: string;
    compareType: string;
    compareRef: string;
    arrowDirection: string;
    filterByColumns: any[];
    bShowFilterPopover$: boolean;
    bContains$: boolean;
    bDateTime$: boolean;
    filterContainsLabel$: string;
    filterContainsType$: string;
    filterContainsValue$: any;
    bIsDate$: boolean;
    bIsDateTime$: boolean;
    bIsTime$: boolean;
    currentFilterRefData: any;
    currentFilterImageEl: any;
    arFilterMainButtons$: any[];
    arFilterSecondaryButtons$: any[];
    selectionMode?: string;
    singleSelectionMode: boolean;
    multiSelectionMode: boolean;
    rowID: any;
    response: any;
    compositeKeys: any;
    showDynamicFields: any;
    filters: any;
    selectParam: any[];
    filterPayload: any;
    ref: any;
    cosmosTableRef: any;
    listContext: any;
    query: any;
    paging: any;
    fieldDefs: any;
    checkBoxValue: string;
    label?: string;
    uniqueId: `${string}-${string}-${string}-${string}-${string}`;
    displayAs: any;
    showRecords: any;
    identifier: string;
    promotedFiltersId: string;
    constructor(psService: ProgressSpinnerService, utils: Utils);
    ngOnInit(): void;
    clearSelectionsAndUpdateTable(getPConnect: any, uniqueId: string, viewName: any): void;
    getFieldFromFilter(filter: any, dateRange?: boolean): any;
    processFilterChange(data: any): void;
    filterBasedOnDateRange(dashboardFilterPayload: any, filter: any, relationalOp: any, selectParam: any, index: any): any;
    processFilterClear(): void;
    getFieldsMetadata(refList: any): Promise<{
        data: _pega_pcore_pconnect_typedefs_analytics_types_data_model.DataObjectMeta;
    }>;
    getValue(col: any): any;
    getListData(): void;
    prepareFilters(data: any): {};
    preparePayload(): void;
    ngOnDestroy(): void;
    drop(event: CdkDragDrop<string[]>): void;
    updateFields(arFields: any[], arColumns: any, fields: any): any[];
    applySearch(event: Event): void;
    fieldOnChange(row: any): void;
    onCheckboxClick(row: any): void;
    isAllSelected(): boolean;
    toggleAllRows(): void;
    _getIconStyle(level: any): string;
    _getGroupName(fieldName: any): any;
    _showButton(name: any, row: any): boolean;
    _listViewClick(column: any, row: any): void;
    _headerSortClick(event: any, columnData: any): void;
    sortCompare(a: any, b: any): number;
    compareByColumnPxRefObjectInsName(aValue: any, bValue: any): number | undefined;
    updateFilterDisplay(type: any): void;
    _filter(event: any, columnData: any): void;
    _clickAway(event: any): void;
    _filterContainsType(event: any): void;
    _filterContainsValue(event: any): void;
    _filterContainsDateValue(event: any, value: any): void;
    _filterContainsDateTimeValue(event: any): void;
    _filterContainsTimeValue(event: any): void;
    _onFilterActionButtonClick(event: any): void;
    updateFilterWithInfo(): void;
    updateFilterVarsWithCurrent(columnData: any): void;
    filterData(item: any): boolean;
    filterDataWithDate(item: any, filterObj: any, filterValue: any): any;
    filterDataWithCommonTypes(item: any, filterObj: any, filterValue: any): any;
    filterSortGroupBy(): void;
    _showUnGroupBy(columnData: any): boolean;
    _groupBy(event: any, columnData: any): void;
    _unGroupBy(event: any, columnData: any): void;
    checkGroupByColumn(field: any, add: any): void;
    addGroups(data: any[], groupByColumns: string[]): any[];
    getSublevel(data: any[], level: number, groupByColumns: string[], parent: Group$1): any[];
    uniqueBy(a: any, key: any): any;
    isGroup(index: any, item: any): boolean;
    _groupHeaderClick(row: any): void;
    customFilterPredicate(data: any | Group$1, filter: string): boolean;
    getDataRowVisible(data: any): boolean;
    getDataRowVisibleWithFilter(data: any, filter: any): boolean;
    updateData(listData: any[], fieldData: any[]): any[];
    openAssignment(row: any): void;
    openWork(row: any): void;
    initializeData(data: any): any;
    getType(field: any): any;
    initializeColumns(fields?: never[]): any[];
    getHeaderCells(colFields: any, fields: any): any;
    buildSelect(fieldDefs: any, colId: any, patchQueryFields?: never[], compositeKeys?: never[]): any;
    getResultsText(): string;
    getField(fieldDefs: any, columnId: any): any;
    getFieldsMap(fieldDefs: any): Map<any, any>;
    addItemKeyInSelect(fieldDefs: any, itemKey: any, select: any, compositeKeys: any): any;
    private getSelectedValue;
    private updateFiltersFromData;
    private buildFilterPayload;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListViewComponent, "app-list-view", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "bInForm$": { "alias": "bInForm$"; "required": false; }; "payload": { "alias": "payload"; "required": false; }; }, {}, never, never, true, never>;
}

interface MultiReferenceReadOnlyProps {
    readonlyContextList: string;
    referenceList: string;
    label: string;
    hideLabel: boolean;
}
declare class MultiReferenceReadonlyComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    configProps$: MultiReferenceReadOnlyProps;
    label: string;
    newPConn: any;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultiReferenceReadonlyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultiReferenceReadonlyComponent, "app-multi-reference-readonly", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class NarrowWideFormComponent implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NarrowWideFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NarrowWideFormComponent, "app-narrow-wide-form", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ObjectPageComponent {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<ObjectPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ObjectPageComponent, "lib-object-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OneColumnComponent extends FormTemplateBase implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OneColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OneColumnComponent, "app-one-column", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OneColumnPageComponent {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<OneColumnPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OneColumnPageComponent, "app-one-column-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OneColumnTabComponent implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OneColumnTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OneColumnTabComponent, "app-one-column-tab", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface PageProps {
    title: string;
    operator?: string;
}
declare class PageComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    configProps$: PageProps;
    arChildren$: any[];
    title$: string;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PageComponent, "app-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class PromotedFiltersComponent implements OnInit, OnDestroy {
    private angularPConnect;
    viewName: any;
    filters: any;
    listViewProps: any;
    pageClass: any;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    parameters: {};
    angularPConnectData: AngularPConnectData;
    showFilters: boolean;
    localeCategory: string;
    localizedVal: any;
    filtersProperties: {};
    showTable: any;
    transientItemID: any;
    processedFilters: any[];
    payload: {};
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    updateSelf(): void;
    formatPromotedFilters(promotedFilters: any): {};
    isValidInput(input: any): boolean;
    getFilterData(): void;
    clearFilterData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PromotedFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PromotedFiltersComponent, "app-promoted-filters", never, { "viewName": { "alias": "viewName"; "required": false; }; "filters": { "alias": "filters"; "required": false; }; "listViewProps": { "alias": "listViewProps"; "required": false; }; "pageClass": { "alias": "pageClass"; "required": false; }; "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "parameters": { "alias": "parameters"; "required": false; }; }, {}, never, never, true, never>;
}

interface RepeatingStructuresProps {
    referenceList?: any[];
    rowClickAction?: string;
}
declare class RepeatingStructuresComponent implements OnInit, AfterViewInit {
    private psService;
    private utils;
    paginator: MatPaginator;
    sort: MatSort;
    pConn$: typeof PConnect;
    configProps$: RepeatingStructuresProps;
    repeatList$: MatTableDataSource<any>;
    fields$: any[];
    displayedColumns$: string[];
    constructor(psService: ProgressSpinnerService, utils: Utils);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    applySearch(event: Event): void;
    rowClick(row: any): void;
    updateData(listData: any[], fieldData: any[]): any[];
    openAssignment(row: any): void;
    initializeData(data: any): any;
    getType(field: any): any;
    initializeColumns(fields?: never[]): any[];
    getDisplayColumns(fields?: any[]): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<RepeatingStructuresComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RepeatingStructuresComponent, "app-repeating-structures", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

interface SimpleTableProps {
    multiRecordDisplayAs: string;
    contextClass: any;
    visibility: boolean;
    label: string;
    propertyLabel: string;
    displayMode: string;
    fieldMetadata: any;
    hideLabel: boolean;
    parameters: any;
    isDataObject: boolean;
    type: string;
    ruleClass: string;
    authorContext: string;
    name: string;
}
declare class SimpleTableComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    bVisible$: boolean;
    configProps$: SimpleTableProps;
    fieldGroupProps: any;
    listViewProps: any;
    refToPConnect: any;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    onStateChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SimpleTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SimpleTableComponent, "app-simple-table", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare const TABLE_CELL = "SdkRenderer";
declare const DELETE_ICON = "DeleteIcon";
declare const getContext: (thePConn: any) => {
    contextName: any;
    referenceListStr: any;
    pageReferenceForRows: any;
    viewName: any;
};
declare const populateRowKey: (rawData: any) => any;
declare const getApiContext: (processedData: any, pConnect: any, reorderCB: any) => {
    fetchData: () => Promise<unknown>;
    fetchPersonalizations: () => Promise<{}>;
    applyRowReorder: (sourceKey: any, destinationKey: any) => Promise<any>;
};
declare const buildMetaForListView: (fieldMetadata: any, fields: any, type: any, ruleClass: any, name: any, propertyLabel: any, isDataObject: any, parameters: any) => {
    name: any;
    config: {
        type: any;
        referenceList: any;
        parameters: any;
        personalization: boolean;
        isDataObject: any;
        grouping: boolean;
        globalSearch: boolean;
        reorderFields: boolean;
        toggleFieldVisibility: boolean;
        title: any;
        personalizationId: string;
        template: string;
        presets: {
            name: string;
            template: string;
            config: {};
            children: {
                name: string;
                type: string;
                children: any;
            }[];
            label: any;
            id: string;
        }[];
        ruleClass: any;
    };
};
declare const getConfigFields: (rawFields: any, contextClass: any, primaryFieldsViewIndex: any) => any;
declare function isFLProperty(label: any): any;
/**
 * [getFieldLabel]
 * Description - A utility that returns resolved field label for "@FL" annotation i.e from data model.
 * @param {Object} fieldConfig
 * @returns {string} resolved label string
 *
 * example:
 * fieldConfig = {label: "@FL .pyID", classID: "TestCase-Work"};
 * return "Case ID"
 */
declare function getFieldLabel(fieldConfig: any): any;
declare const updateFieldLabels: (fields: any, configFields: any, primaryFieldsViewIndex: any, pConnect: any, options: any) => any;
declare const buildFieldsForTable: (configFields: any, pConnect: any, showDeleteButton: any, options: any) => any;
declare const createMetaForTable: (fields: any, renderMode: any) => {
    height: {
        minHeight: string;
        fitHeightToElement: string;
        deltaAdjustment: string;
        autoSize: boolean;
    };
    fieldDefs: any;
    itemKey: string;
    grouping: boolean;
    reorderFields: boolean;
    reorderItems: boolean;
    dragHandle: boolean;
    globalSearch: boolean;
    personalization: boolean;
    toggleFieldVisibility: boolean;
    toolbar: boolean;
    footer: boolean;
    filterExpression: null;
    editing: boolean;
    timezone: string | undefined;
};
declare const filterDataByDate: (item: any, filterObj: any) => boolean;
declare const filterDataByCommonFields: (item: any, filterObj: any) => boolean;
/**
 * This method returns a callBack function for Add action.
 * @param {object} pConnect - PConnect object
 * @param {number} index - index of the page list to add
 */
declare const getAddRowCallback: (pConnect: any, index: any) => () => any;
/**
 * This method creates a PConnect object with proper options for Add and Delete actions
 * @param {string} contextName - contextName
 * @param {string} referenceList - referenceList
 * @param {string} pageReference - pageReference
 */
declare const createPConnect: (contextName: any, referenceList: any, pageReference: any) => _pega_pcore_pconnect_typedefs_interpreter_c11n_env.C11nEnv;

interface SimpleTableManualProps {
    visibility?: boolean;
    grouping?: any;
    referenceList?: any[];
    children?: any[];
    renderMode?: string;
    presets?: any[];
    label?: string;
    showLabel?: boolean;
    dataPageName?: string;
    contextClass?: string;
    propertyLabel?: string;
    fieldMetadata?: any;
    allowActions?: any;
    allowTableEdit?: boolean;
    allowRowDelete?: any;
    editMode?: string;
    addAndEditRowsWithin?: any;
    viewForAddAndEditModal?: any;
    editModeConfig?: any;
    displayMode?: string;
    useSeparateViewForEdit: any;
    viewForEditModal: any;
    targetClassLabel: string;
}
declare class Group {
    level: number;
    parent: Group;
    expanded: boolean;
    totalCounts: number;
    get visible(): boolean;
}
declare class SimpleTableManualComponent implements OnInit, OnDestroy {
    private angularPConnect;
    utils: Utils;
    private dataPageService;
    sort: MatSort;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    configProps$: SimpleTableManualProps;
    fields$: any[];
    bVisible$: boolean;
    displayedColumns: string[];
    rowData: MatTableDataSource<any>;
    originalData: any[];
    processedFields: any[];
    fieldDefs: any[];
    requestedReadOnlyMode: boolean;
    readOnlyMode: boolean;
    editableMode: boolean;
    menuIconOverride$: string;
    pageReference: string;
    referenceList: any;
    contextClass: any;
    showAddRowButton: boolean;
    prevReferenceList: any[];
    elementsData: MatTableDataSource<any>;
    originalElementsData: MatTableDataSource<any>;
    rawFields: any;
    label?: string;
    searchIcon$: string;
    bShowSearch$: boolean;
    bColumnReorder$: boolean;
    bGrouping$: boolean;
    perfFilter: string;
    searchFilter: string;
    menuSvgIcon$: string;
    arrowSvgIcon$: string;
    arrowDownSvgIcon$: string;
    arrowUpSvgIcon$: string;
    filterSvgIcon$: string;
    filterOnSvgIcon$: string;
    groupBySvgIcon$: string;
    groupByColumns$: string[];
    compareType: string;
    compareRef: string;
    arrowDirection: string;
    filterByColumns: any[];
    currentFilterRefData: any;
    filterContainsLabel$: string;
    filterContainsType$: string;
    filterContainsValue$: any;
    bShowFilterPopover$: boolean;
    bContains$: boolean;
    bDateTime$: boolean;
    bIsDate$: boolean;
    bIsDateTime$: boolean;
    bIsTime$: boolean;
    currentFilterImageEl: any;
    arFilterMainButtons$: any[];
    arFilterSecondaryButtons$: any[];
    selectionMode: string;
    singleSelectionMode: boolean;
    multiSelectionMode: boolean;
    rowID: any;
    response: any;
    compositeKeys: any;
    parameters: any;
    allowEditingInModal: boolean;
    defaultView: any;
    referenceListStr: any;
    bUseSeparateViewForEdit: any;
    editView: any;
    settingsSvgIcon$: string;
    isInitialized: boolean;
    targetClassLabel: string;
    localizedVal: (localeKey: string, localePath?: string, localeRuleKey?: string | null, componentName?: string | null) => string;
    localeCategory: string;
    constructor(angularPConnect: AngularPConnectService, utils: Utils, dataPageService: DatapageService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    checkIfAllowActionsOrRowEditingExist(newflagobject: any): any;
    initializeDefaultPageInstructions(): void;
    getResultsText(): string;
    sortCompare(a: any, b: any): number;
    compareByColumnPxRefObjectInsName(aValue: any, bValue: any): number | undefined;
    updateFilterDisplay(type: any): void;
    _filter(event: any, columnData: any): void;
    _clickAway(event: any): void;
    _filterContainsType(event: any): void;
    _filterContainsValue(event: any): void;
    _filterContainsDateValue(event: any, value: any): void;
    _filterContainsDateTimeValue(event: any): void;
    _filterContainsTimeValue(event: any): void;
    _onFilterActionButtonClick(event: any): void;
    updateFilterWithInfo(): void;
    updateFilterVarsWithCurrent(columnData: any): void;
    filterData(element: any): boolean;
    filterSortGroupBy(): void;
    _headerSortClick(event: any, columnData: any): void;
    _showUnGroupBy(columnData: any): boolean;
    _groupBy(event: any, columnData: any): void;
    _unGroupBy(event: any, columnData: any): void;
    checkGroupByColumn(field: any, add: any): void;
    _getGroupName(fieldName: any): any;
    addGroups(data: any[], groupByColumns: string[]): any[];
    getSublevel(data: any[], level: number, groupByColumns: string[], parent: Group): any[];
    uniqueBy(a: any, key: any): any;
    isGroup(index: any, item: any): boolean;
    _groupHeaderClick(row: any): void;
    customFilterPredicate(data: any | Group, filter: string): boolean;
    getDataRowVisible(data: any): boolean;
    getDataRowVisibleWithFilter(data: any, filter: any): boolean;
    getDisplayColumns(fields?: never[]): any[];
    _getIconStyle(level: any): string;
    onStateChange(): void;
    getRowValue(inRowData: object, inColKey: string): any;
    generateRowsData(): void;
    formatRowsData(data: any): any;
    addRecord(): void;
    editRecord(data: any, index: any): void;
    deleteRecord(index: any): void;
    buildElementsForTable(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SimpleTableManualComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SimpleTableManualComponent, "app-simple-table-manual", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SimpleTableSelectComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    label: string;
    renderMode: string;
    showLabel: boolean;
    viewName: string;
    parameters: {};
    dataRelationshipContext: string;
    propsToUse: any;
    showSimpleTableManual: boolean;
    isSearchable: boolean;
    filters: any;
    listViewProps: any;
    pageClass: any;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    updateSelf(): void;
    processFiltrers(theConfigProps: any, compositeKeys: any): void;
    isSelfReferencedProperty(param: any, referenceProp: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SimpleTableSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SimpleTableSelectComponent, "app-simple-table-select", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SingleReferenceReadonlyComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    dataRelationshipContext?: any;
    angularPConnectData: AngularPConnectData;
    configProps: any;
    component: any;
    label: string;
    newPconn: typeof PConnect;
    displayMode: string;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleReferenceReadonlyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SingleReferenceReadonlyComponent, "app-single-reference-readonly", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; "dataRelationshipContext": { "alias": "dataRelationshipContext"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SubTabsComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    arChildren$: any[];
    defaultTabIndex: number;
    currentTabId: string;
    tabItems: any[];
    availableTabs: any;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    updateTabContent(): void;
    handleTabClick(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SubTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SubTabsComponent, "app-sub-tabs", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ThreeColumnComponent extends FormTemplateBase implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThreeColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThreeColumnComponent, "app-three-column", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ThreeColumnPageComponent {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThreeColumnPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThreeColumnPageComponent, "app-three-column-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TwoColumnComponent extends FormTemplateBase implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TwoColumnComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TwoColumnComponent, "app-two-column", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TwoColumnPageComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TwoColumnPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TwoColumnPageComponent, "app-two-column-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class TwoColumnTabComponent implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TwoColumnTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TwoColumnTabComponent, "app-two-column-tab", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class WideNarrowFormComponent extends FormTemplateBase implements OnInit, OnChanges {
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WideNarrowFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WideNarrowFormComponent, "app-wide-narrow-form", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class WideNarrowPageComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    thePConnType: string | undefined;
    angularPConnectData: AngularPConnectData;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WideNarrowPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WideNarrowPageComponent, "app-wide-narrow-page", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare function getAllFields(pConnect: any): never[];
declare function filterForFieldValueList(fields: any): any;
/**
 * This method evaluates whether a row action is allowed based on the provided conditions.
 * @param {string|boolean|undefined} allowRowDelete - The condition for allowing row deletion.
 * @param {object} rowData - The data of the row being evaluated.
 * @returns {boolean} - Returns true if the row action is allowed, false otherwise.
 */
declare const evaluateAllowRowAction: (allowRowDelete: any, rowData: any) => boolean;
declare function prepareCaseSummaryData(caseSummaryRegion: any, portalSpecificVisibilityChecker?: any): {
    primarySummaryFields: any;
    secondarySummaryFields: any;
};

interface AppAnnouncementProps {
    header?: string;
    description?: string;
    whatsnewlink?: string;
    label?: string;
    datasource?: any;
}
declare class AppAnnouncementComponent implements OnInit {
    pConn$: typeof PConnect;
    configProps$: AppAnnouncementProps;
    details$: any[];
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AppAnnouncementComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppAnnouncementComponent, "app-app-announcement", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AttachmentComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    angularPConnectData: AngularPConnectData;
    fileInput: ElementRef;
    localizationService: any;
    contextName: string;
    actionSequencer: any;
    caseID: any;
    label$: string;
    value$: any;
    bRequired$: boolean;
    bReadonly$: boolean;
    bDisabled$: boolean;
    bVisible$: boolean;
    allowMultiple$: boolean;
    extensions$: string;
    displayMode: string | undefined;
    status: string;
    validateMessage: string | undefined;
    valueRef: string;
    localizedVal: (localeKey: string, localePath?: string, localeRuleKey?: string | null, componentName?: string | null) => string;
    uploadMultipleFilesLabel: string;
    uploadSingleFileLabel: string;
    filesWithError: any;
    files: any;
    srcImg: any;
    deleteIcon: string;
    tempFilesToBeUploaded: any[];
    attachments: any;
    attachmentCount: number;
    isOldAttachment: boolean;
    multiAttachmentsInInlineEdit: any;
    isMultiAttachmentInInlineEditTable: any;
    overrideLocalState: boolean;
    constructor(angularPConnect: AngularPConnectService, utils: Utils);
    ngOnInit(): void;
    checkAndUpdate(): void;
    onStateChange(): void;
    updateSelf(): void;
    updateAttachments(): void;
    downloadFile(fileObj: any): void;
    deleteFile(file: any, fileIndex: number): void;
    onFileAdded(event: any): void;
    onUploadProgress(id: any, ev: any): void;
    populateErrorAndUpdateRedux(file: any): void;
    errorHandler(isFetchCanceled: any, file: any): (error: any) => never;
    uploadFiles(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AttachmentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AttachmentComponent, "app-attachment", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

interface CaseHistoryProps {
    label?: string;
}
declare class CaseHistoryComponent implements OnInit {
    private utils;
    pConn$: typeof PConnect;
    configProps$: CaseHistoryProps;
    repeatList$: MatTableDataSource<any>;
    fields$: any[];
    displayedColumns$: any[];
    waitingForData: boolean;
    constructor(utils: Utils);
    ngOnInit(): void;
    updateData(listData: any[], fieldData: any[]): any[];
    getDisplayColumns(fields?: any[]): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseHistoryComponent, "app-case-history", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FeedContainerComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private cdRef;
    private utils;
    pConn$: typeof PConnect;
    angularPConnectData: AngularPConnectData;
    userName$: string | undefined;
    imageKey$: string | undefined;
    currentUserInitials$: string;
    currentUserName$: string;
    pulseMessages$: any[];
    showReplyComment$: object;
    svgComment$: string;
    svgLike$: string;
    svgLikedByMe$: string;
    svgSend$: string;
    pulseConversation: string;
    userData: Map<any, any>;
    pulseComment: object;
    actionsAPI: any;
    feedAPI: any;
    pulseData: any;
    fetchMessages: any;
    likeMessage: any;
    postMessage: any;
    constructor(angularPConnect: AngularPConnectService, cdRef: ChangeDetectorRef, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    updateSelf(): void;
    getMessageData(): void;
    convertToArray(messages: any[]): any[];
    appendPulseMessage(messages: any[]): any[];
    updateMessagesWithOperators(): void;
    updateCurrentUserName(sUser: string): void;
    postClick(): void;
    messageChange(event: any): void;
    likeClick(messageID: string, rMessageID: string, bLikedByMe: boolean, level: string): void;
    commentClick(messageID: any): void;
    postCommentClick(messageID: any): void;
    newCommentChange(event: any, messageID: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FeedContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FeedContainerComponent, "app-feed-container", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class FileUtilityComponent implements OnInit, OnDestroy {
    private angularPConnect;
    private utils;
    private ngZone;
    pConn$: typeof PConnect;
    angularPConnectData: AngularPConnectData;
    arFullListAttachments: any[];
    lu_name$: string;
    lu_icon$: string;
    lu_bLoading$: boolean;
    lu_count$: number;
    lu_arActions$: any[];
    lu_arItems$: any;
    va_arItems$: any[];
    lu_onViewAllFunction: any;
    bShowFileModal$: boolean;
    bShowLinkModal$: boolean;
    bShowViewAllModal$: boolean;
    arFileMainButtons$: any[];
    arFileSecondaryButtons$: any[];
    arLinkMainButtons$: any[];
    arLinkSecondaryButtons$: any[];
    arFiles$: any[];
    arFileList$: any[];
    removeFileFromList$: any;
    arLinks$: any[];
    arLinksList$: any[];
    removeLinksFromList$: any;
    link_title$: string;
    link_url$: string;
    closeSvgIcon$: string;
    currentCaseID: string;
    debouncedGetAttachments: any;
    attachSubId: any;
    addAttachmentsActions: any;
    constructor(angularPConnect: AngularPConnectService, utils: Utils, ngZone: NgZone);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    onAttachFiles(files?: any[]): void;
    refreshAttachments(): void;
    onUploadProgress(): void;
    errorHandler(): void;
    onAttachLinks(links: any): void;
    addAttachments(attsFromResp?: any[]): any[];
    onViewAll(): void;
    _closeViewAll(): void;
    removeFileFromList(item: any): void;
    removeLinksFromList(item: any): void;
    getNewListUtilityItemProps: ({ att, cancelFile, downloadFile, deleteFile, removeFile }: {
        att: any;
        cancelFile: any;
        downloadFile: any;
        deleteFile: any;
        removeFile: any;
    }) => {
        id: any;
        visual: {
            icon: any;
            progress: any;
        };
        primary: {
            type: any;
            name: any;
            icon: string;
            click: any;
        };
        secondary: {
            text: any;
        };
        actions: any;
    };
    getListUtilityItemProps: ({ att, cancelFile, downloadFile, deleteFile, removeFile }: {
        att: any;
        cancelFile: any;
        downloadFile: any;
        deleteFile: any;
        removeFile: any;
    }) => {
        id: any;
        visual: {
            icon: any;
            progress: any;
        };
        primary: {
            type: any;
            name: any;
            icon: string;
            click: any;
        };
        secondary: {
            text: any;
        };
        actions: any;
    };
    _addLink(): void;
    _changeTitle(event: any): void;
    _changeUrl(event: any): void;
    downloadFile(att: any): void;
    fileDownload: (data: any, fileName: any, ext: any) => void;
    cancelFile(): void;
    deleteFile(att: any): void;
    removeFile(): void;
    removeNewFile(): void;
    createModal(modalType: string): void;
    createModalButtons(): void;
    uploadMyFiles($event: any): void;
    getFiles(arFiles: any[]): any[];
    setNewFiles(arFiles: any): any;
    validateMaxSize(fileObj: any, maxSizeInMB: any): boolean;
    onFileActionButtonClick(event: any): void;
    onLinkActionButtonClick(event: any): void;
    clearOutFiles(): void;
    clearOutLinks(): void;
    addALink(): void;
    _fieldOnChangeLink(event: any): void;
    _fieldOnChangeURL(event: any): void;
    updateSelf(): void;
    getCaseID(): any;
    fetchCaseAttachments(caseID: any): Promise<object>;
    handleAttachmentsResponse(resp: any): void;
    getUtilityItems(attachments: any): any;
    mapAttachmentToUtilityItem(att: any): {
        id: any;
        visual: {
            icon: any;
            progress: any;
        };
        primary: {
            type: any;
            name: any;
            icon: string;
            click: any;
        };
        secondary: {
            text: any;
        };
        actions: any;
    };
    getDownloadFunction(att: any): (() => void) | null;
    getCancelFunction(att: any): (() => void) | null;
    getDeleteFunction(att: any): (() => void) | null;
    getRemoveFunction(att: any): (() => void) | null;
    caseHasChanged(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUtilityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileUtilityComponent, "app-file-utility", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class ListUtilityComponent implements OnInit {
    private utils;
    name$: string;
    icon$: string;
    bLoading$: boolean;
    count$: number;
    arActions$: any[];
    arItems$: any[];
    menuIconOverrideAction$: any[];
    onViewAll$: any;
    headerSvgIcon$: string;
    settingsSvgIcon$: string;
    noItemsMessage$: string;
    imagePath$: string;
    constructor(utils: Utils);
    ngOnInit(): void;
    getIconPath(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListUtilityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListUtilityComponent, "app-list-utility", never, { "name$": { "alias": "name$"; "required": false; }; "icon$": { "alias": "icon$"; "required": false; }; "bLoading$": { "alias": "bLoading$"; "required": false; }; "count$": { "alias": "count$"; "required": false; }; "arActions$": { "alias": "arActions$"; "required": false; }; "arItems$": { "alias": "arItems$"; "required": false; }; "menuIconOverrideAction$": { "alias": "menuIconOverrideAction$"; "required": false; }; "onViewAll$": { "alias": "onViewAll$"; "required": false; }; }, {}, never, never, true, never>;
}

interface ToDoProps {
    datasource?: any;
    headerText?: string;
    myWorkList?: any;
    label?: string;
    readOnly?: boolean;
}
declare class TodoComponent implements OnInit, OnDestroy {
    private psService;
    private erService;
    private utils;
    pConn$: typeof PConnect;
    caseInfoID$: string;
    datasource$: any;
    headerText$?: string;
    showTodoList$: boolean;
    target$: string;
    type$: string;
    context$: string;
    myWorkList$: any;
    isConfirm: any;
    configProps$: ToDoProps;
    currentUser$: string | undefined;
    currentUserInitials$: string;
    bShowMore$: boolean;
    arAssignments$: any[];
    assignmentsSource$: any;
    CONSTS: typeof publicConstants;
    bLogging: boolean;
    localizedVal: (localeKey: string, localePath?: string, localeRuleKey?: string | null, componentName?: string | null) => string;
    localeUtils: _pega_pcore_pconnect_typedefs_locale_locale_utils.LocaleUtils;
    localeCategory: string;
    showlessLocalizedValue: string;
    showMoreLocalizedValue: string;
    goLocalizedValue: string;
    count: number;
    constructor(psService: ProgressSpinnerService, erService: ErrorMessagesService, utils: Utils);
    ngOnInit(): void;
    ngOnDestroy(): void;
    get canPerform(): boolean;
    updateList(): void;
    updateToDo(): void;
    deferLoadWorklistItems(responseData: any): void;
    getID(assignment: any): any;
    topThreeAssignments(assignmentsSource: any[]): any[];
    getAssignmentId(assignment: any): any;
    getPriority(assignment: any): any;
    getAssignmentName(assignment: any): string;
    getCaseInfoAssignment(assignmentsSource: any[], caseInfoID: string): any[];
    _showMore(): void;
    _showLess(): void;
    isChildCase(assignment: any): any;
    clickGo(assignment: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TodoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TodoComponent, "app-todo", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "caseInfoID$": { "alias": "caseInfoID$"; "required": false; }; "datasource$": { "alias": "datasource$"; "required": false; }; "headerText$": { "alias": "headerText$"; "required": false; }; "showTodoList$": { "alias": "showTodoList$"; "required": false; }; "target$": { "alias": "target$"; "required": false; }; "type$": { "alias": "type$"; "required": false; }; "context$": { "alias": "context$"; "required": false; }; "myWorkList$": { "alias": "myWorkList$"; "required": false; }; "isConfirm": { "alias": "isConfirm"; "required": false; }; }, {}, never, never, true, never>;
}

interface UtilityProps {
    headerIcon?: string;
    headerText?: string;
    noItemsMessage?: string;
}
declare class UtilityComponent implements OnInit, OnChanges {
    private utils;
    pConn$: typeof PConnect;
    configProps$: UtilityProps;
    headerIcon$?: string;
    headerText$?: string;
    headerIconUrl$?: string;
    noItemsMessage$?: string;
    constructor(utils: Utils);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UtilityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UtilityComponent, "app-utility", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AlertComponent {
    message: any[];
    severity: any;
    hideClose: any;
    onClose: EventEmitter<any>;
    getMatIcon(severity: any): any;
    onCloseClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "app-alert", never, { "message": { "alias": "message"; "required": false; }; "severity": { "alias": "severity"; "required": false; }; "hideClose": { "alias": "hideClose"; "required": false; }; }, { "onClose": "onClose"; }, never, never, true, never>;
}

declare class AlertBannerComponent {
    banners: any[];
    SEVERITY_MAP: {
        urgent: string;
        warning: string;
        success: string;
        info: string;
    };
    onAlertClose(config: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertBannerComponent, "app-alert-banner", never, { "banners": { "alias": "banners"; "required": false; }; }, {}, never, never, true, never>;
}

declare class CaseCreateStageComponent implements OnInit, OnDestroy {
    private angularPConnect;
    pConn$: typeof PConnect;
    formGroup$: FormGroup;
    arChildren$: any[];
    angularPConnectData: AngularPConnectData;
    constructor(angularPConnect: AngularPConnectService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onStateChange(): void;
    checkAndUpdate(): void;
    updateSelf(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseCreateStageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseCreateStageComponent, "app-case-create-stage", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "formGroup$": { "alias": "formGroup$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MaterialCaseSummaryComponent implements OnInit, OnChanges {
    private utils;
    status$: string;
    bShowStatus$: boolean;
    primaryFields$: any[];
    secondaryFields$: any[];
    primaryFieldsWithStatus$: any[];
    constructor(utils: Utils);
    localizedVal: (localeKey: string, localePath?: string, localeRuleKey?: string | null, componentName?: string | null) => string;
    localeCategory: string;
    ngOnInit(): void;
    ngOnChanges(): void;
    updateLabelAndDate(arData: any[]): void;
    updatePrimaryWithStatus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialCaseSummaryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaterialCaseSummaryComponent, "app-material-case-summary", never, { "status$": { "alias": "status$"; "required": false; }; "bShowStatus$": { "alias": "bShowStatus$"; "required": false; }; "primaryFields$": { "alias": "primaryFields$"; "required": false; }; "secondaryFields$": { "alias": "secondaryFields$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MaterialDetailsComponent {
    private utils;
    constructor(utils: Utils);
    arFields$: any[];
    arFields2$: any[];
    arFields3$: any[];
    arHighlightedFields: any[];
    layout: any;
    _getValue(configValue: any): any;
    _formatDate(dateValue: string, dateFormat: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaterialDetailsComponent, "app-material-details", never, { "arFields$": { "alias": "arFields$"; "required": false; }; "arFields2$": { "alias": "arFields2$"; "required": false; }; "arFields3$": { "alias": "arFields3$"; "required": false; }; "arHighlightedFields": { "alias": "arHighlightedFields"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MaterialDetailsFieldsComponent {
    private utils;
    constructor(utils: Utils);
    arFields$: any[];
    arHighlightedFields: any[];
    _getValue(configValue: any, field?: any): any;
    _formatDate(dateValue: string, dateFormat: string): string;
    getVisibility(config: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialDetailsFieldsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaterialDetailsFieldsComponent, "app-material-details-fields", never, { "arFields$": { "alias": "arFields$"; "required": false; }; "arHighlightedFields": { "alias": "arHighlightedFields"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MaterialSummaryItemComponent implements OnInit {
    private utils;
    item$: any;
    menuIconOverride$: string;
    menuIconOverrideAction$: any;
    settingsSvgIcon$: string;
    imagePath$: string;
    constructor(utils: Utils);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialSummaryItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaterialSummaryItemComponent, "app-material-summary-item", never, { "item$": { "alias": "item$"; "required": false; }; "menuIconOverride$": { "alias": "menuIconOverride$"; "required": false; }; "menuIconOverrideAction$": { "alias": "menuIconOverrideAction$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MaterialSummaryListComponent {
    arItems$: any[];
    icon$: string;
    menuIconOverride$: string;
    menuIconOverrideAction$: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialSummaryListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaterialSummaryListComponent, "app-material-summary-list", never, { "arItems$": { "alias": "arItems$"; "required": false; }; "icon$": { "alias": "icon$"; "required": false; }; "menuIconOverride$": { "alias": "menuIconOverride$"; "required": false; }; "menuIconOverrideAction$": { "alias": "menuIconOverrideAction$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MaterialUtilityComponent implements OnInit {
    private utils;
    headerText$: string;
    headerIcon$: string;
    headerIconUrl$: string;
    noItemsMessage$: string;
    headerSvgIcon$: string;
    settingsSvgIcon$: string;
    constructor(utils: Utils);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialUtilityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaterialUtilityComponent, "app-material-utility", never, { "headerText$": { "alias": "headerText$"; "required": false; }; "headerIcon$": { "alias": "headerIcon$"; "required": false; }; "headerIconUrl$": { "alias": "headerIconUrl$"; "required": false; }; "noItemsMessage$": { "alias": "noItemsMessage$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class MaterialVerticalTabsComponent implements OnInit {
    tabConfig$: any[];
    tabClick: EventEmitter<any>;
    selectedTabId$: any;
    ngOnInit(): void;
    onChange(tab: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialVerticalTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MaterialVerticalTabsComponent, "app-material-vertical-tabs", never, { "tabConfig$": { "alias": "tabConfig$"; "required": false; }; }, { "tabClick": "tabClick"; }, never, never, true, never>;
}

declare class OperatorComponent implements OnInit, OnChanges, OnDestroy {
    private el;
    private renderer;
    private cdRef;
    private utils;
    pConn$: typeof PConnect;
    displayLabel: any;
    name$?: string;
    fields$: any[];
    bShowPopover$: boolean;
    date$: string;
    label$: string;
    id$: string;
    constructor(el: ElementRef, renderer: Renderer2, cdRef: ChangeDetectorRef, utils: Utils);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    updateSelf(): void;
    showOperator(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OperatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OperatorComponent, "app-operator", never, { "pConn$": { "alias": "pConn$"; "required": false; }; "displayLabel": { "alias": "displayLabel"; "required": false; }; "name$": { "alias": "name$"; "required": false; }; }, {}, never, never, true, never>;
}

interface PulseProps {
    children?: any[];
}
declare class PulseComponent implements OnInit {
    pConn$: typeof PConnect;
    configProps$: PulseProps;
    currentUser$: string | undefined;
    currentUserInitials$: string | undefined;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PulseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PulseComponent, "app-pulse", never, { "pConn$": { "alias": "pConn$"; "required": false; }; }, {}, never, never, true, never>;
}

declare class RichTextEditorComponent implements OnChanges {
    placeholder: any;
    disabled: any;
    readonly: any;
    value: any;
    label: any;
    required: any;
    info: any;
    error: any;
    testId: any;
    onBlur: EventEmitter<any>;
    onChange: EventEmitter<any>;
    richText: FormControl<any>;
    editorConfig: any;
    ngOnChanges(): void;
    filePickerCallback: (cb: any) => void;
    blur(): void;
    change(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTextEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RichTextEditorComponent, "app-rich-text-editor", never, { "placeholder": { "alias": "placeholder"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "value": { "alias": "value"; "required": false; }; "label": { "alias": "label"; "required": false; }; "required": { "alias": "required"; "required": false; }; "info": { "alias": "info"; "required": false; }; "error": { "alias": "error"; "required": false; }; "testId": { "alias": "testId"; "required": false; }; }, { "onBlur": "onBlur"; "onChange": "onChange"; }, never, never, true, never>;
}

declare class ThousandSeparatorDirective {
    private el;
    constructor(el: ElementRef);
    onInput(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThousandSeparatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ThousandSeparatorDirective, "[appThousandSeparator]", never, {}, {}, never, never, true, never>;
}

declare class CaseService {
    private http;
    private scService;
    constructor(http: HttpClient, scService: ServerConfigService);
    caseTypeUrl: string;
    getCaseTypes(): rxjs.Observable<_angular_common_http.HttpResponse<Object>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseService>;
}

declare const loginBoxType: {
    Main: number;
    Popup: number;
    Modal: number;
};
declare const endpoints: {
    loginExperience: number;
    AUTH: string;
    CASES: string;
    CASES_V2: string;
    CASETYPES: string;
    CASETYPES_V2: string;
    CONFIG_V2: string;
    VIEWS: string;
    ASSIGNMENTS: string;
    ASSIGNMENTS_V2: string;
    ACTIONS: string;
    PAGES: string;
    DATA: string;
    DATA_V2: string;
    REFRESH: string;
    BACK_V2: string;
    PULSE: string;
    PULSE_V2: string;
    ROUTING: string;
    MEDIACO: string;
    API: string;
    EMBEDDED: string;
    EMBEDDEDHTML: string;
    MASHUP: string;
    MASHUPHTML: string;
    SIMPLEPORTAL: string;
    SIMPLEPORTALHTML: string;
    PORTAL: string;
    PORTALHTML: string;
    FULLPORTAL: string;
    FULLPORTALHTML: string;
};

declare class GoogleMapsLoaderService {
    private loadingPromise?;
    load(apiKey: string): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<GoogleMapsLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GoogleMapsLoaderService>;
}

/**
 * Function that accepts array of messages as input and group them by their type and returns the resulting object
 * @param {Array} inputMessages
 * Eg: [
 * {message: 'First Name is required', type: 'error'},
 * {message: 'Last Name is required', type: 'error'},
 * {message: 'Address field should be clear and precise', type: 'info'}
 * ]
 *
 * @returns {object}
 *
 * Eg: {
 *  error: ['First Name is required', 'Last Name is required'],
 *  info: ['Address field should be clear and precise']
 * }
 */
declare function getMessagesGrouped(inputMessages: any): {};
declare function getBanners(config: any): any;

declare function getLocale(locale?: string): string | undefined;
declare function getCurrentTimezone(timezone?: string): string;
declare function getSeconds(sTime: any): any;

declare function updateWorkList(pConnect: any, key: any, payload?: undefined): void;

declare const getCurrencyOptions: (inISOCode: string) => {
    locale: string;
    style: string;
    currency: string;
};
declare const getCurrencyCharacters: (inISOCode: string) => {
    theCurrencySymbol: string;
    theDecimalIndicator: string;
    theDigitGroupSeparator: string;
};

declare const dateFormatInfoDefault: {
    dateFormatString: string;
    dateFormatStringLong: string;
    dateFormatStringLC: string;
    dateFormatMask: string;
};
declare const getDateFormatInfo: () => {
    dateFormatString: string;
    dateFormatStringLong: string;
    dateFormatStringLC: string;
    dateFormatMask: string;
};

declare function handleEvent(actions: any, eventType: any, propName: any, value: any): void;

/**
 *
 * @param {*} pConn - pConnect object of the view
 * @returns {string} - returns the name of referenceList
 */
declare const getReferenceList: (pConn: any) => any;
/**
 * creates and returns react element of the view
 * @param {*} pConn - pConnect object of the view
 * @param {*} index - index of the fieldGroup item
 * @param {*} viewConfigPath - boolean value to check for children in config
 * @returns {*} - return the react element of the view
 */
declare const buildView: (pConn: any, index: any, viewConfigPath: any) => _pega_pcore_pconnect_typedefs_interpreter_types.CreateC11nEnv;

declare const createFilter: (value: any, fieldId: any, comparator?: string) => {
    condition: {
        lhs: {
            field: any;
        };
        comparator: string;
        rhs: {
            value: any;
        };
    };
};
declare const combineFilters: (filterList: any, existingFilters: any) => any;
declare const createFilterComponent: (getPConnect: any, filterMeta: any, index: any) => {
    type: any;
    getPConnect: any;
    name: any;
    filterProp: string;
    metadata: any;
    label: any;
    filterId: any;
    c11nEnv?: undefined;
} | {
    type: any;
    getPConnect: any;
    name: any;
    filterProp: string;
    metadata: any;
    c11nEnv: _pega_pcore_pconnect_typedefs_interpreter_types.CreateC11nEnv;
    filterId: any;
    label?: undefined;
};
declare const buildFilterComponents: (getPConnect: any, allFilters: any) => any;
declare const getFilterExpression: (filterValue: any, name: any, metadata: any) => "" | {
    condition: {
        lhs: {
            field: any;
        };
        comparator: string;
        rhs: {
            value: any;
        };
    };
} | null;
declare const getFormattedDate: (date: any) => any;

declare const BooleanFormatters: {
    TrueFalse: (value: any, options: any) => any;
};

declare const CurrencyFormatters: {
    Currency: (value: any, options: any) => string;
    'Currency-Code': (value: any, options: any) => string;
    Decimal: (value: any, options: any) => string;
    'Decimal-Auto': (value: any, options: any) => string;
    Integer: (value: any, options: any) => string;
    Percentage: (value: any, options: any) => string;
};

declare const currencyMap: {
    AF: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CV: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KYD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BJ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BF: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CF: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GQ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ML: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DJ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    EG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SV: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ER: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ET: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    FK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    FJ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XAU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ID: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IQ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JEP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MV: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MX: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    OM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PF: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    WF: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XPD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XPT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    QA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    WS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ST: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XAG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TJ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    US: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    FM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    YE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    YU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    EE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    FI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    FR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LV: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ME: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ES: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
};

declare const DateFormatters: {
    'DateTime-Long': (value: any, options: any) => string;
    'DateTime-Short': (value: any, options: any) => string;
    'DateTime-Since': (value: any) => string;
    'Time-Only': (value: any, options: any) => any;
    convertToTimezone: (value: any, options: any) => any;
    convertFromTimezone: (value: any, timezone: any) => any;
    Date: (value: any, options: any) => string;
};

declare const formatters: {
    Currency: (value: any, options: any) => any;
    'Currency-Code': (value: any, options: any) => any;
    Decimal: (value: any, options: any) => any;
    'Decimal-Auto': (value: any, options: any) => any;
    Integer: (value: any, options: any) => any;
    Percentage: (value: any, options: any) => any;
};

declare const CommonFormatters: {
    'DateTime-Long': (value: any, options: any) => string;
    'DateTime-Short': (value: any, options: any) => string;
    'DateTime-Since': (value: any) => string;
    'Time-Only': (value: any, options: any) => any;
    convertToTimezone: (value: any, options: any) => any;
    convertFromTimezone: (value: any, timezone: any) => any;
    Date: (value: any, options: any) => string;
    Currency: (value: any, options: any) => string;
    'Currency-Code': (value: any, options: any) => string;
    Decimal: (value: any, options: any) => string;
    'Decimal-Auto': (value: any, options: any) => string;
    Integer: (value: any, options: any) => string;
    Percentage: (value: any, options: any) => string;
    TrueFalse: (value: any, options: any) => any;
};
declare function format(value: any, type: any, options?: {}): string;

declare function updateNewInstructions(c11nEnv: any, selectionList: any): void;
declare function insertInstruction(c11nEnv: any, selectionList: any, selectionKey: any, primaryField: any, item: any): void;
declare function deleteInstruction(c11nEnv: any, selectionList: any, selectionKey: any, item: any): void;

declare function getLeafNameFromPropertyName(property: any): string;
declare function isSelfReferencedProperty(param: any, referenceProp: any): boolean;
declare function getCompositeKeys(c11nEnv: any, property: any): any;
declare function generateColumns(config: any, pConn: any, referenceType: any): void;
declare function getDataRelationshipContextFromKey(key: any): any;

declare function getDataReferenceInfo(pConnect: any, dataRelationshipContext: any, contextPage: any): {
    dataContext?: undefined;
    dataContextParameters?: undefined;
} | {
    dataContext: any;
    dataContextParameters: {};
};
declare function isLinkTextEmpty(text: any): boolean;

declare const getDeferFriendlyTabs: (allTabs: any) => any;
declare const searchtabsClick: (id: any, mainTabs: any, currentTabId: any) => void;
declare const getVisibleTabs: (allTabs: any, uuid: any) => any;
declare const getTransientTabs: (availableTabs: any, currentTabId: any, tabItems: any) => any;
declare const tabClick: (id: any, availableTabs: any, currentTabId: any, tabItems: any) => void;
declare const getTabLabel: (tabPConnect: any) => any;
declare const getActiveTabId: (mainTabs: any, currentTabId: any) => any;
declare const getFirstVisibleTabId: (deferLoadedTabs: any, tabViewName: any) => string | null;

/**
 * versionHelpers.ts
 *
 * Container helper functions that can identify which version of
 * PCore/PConnect is being run
 */
declare const sdkVersion = "8.7";
declare function compareSdkPCoreVersions(): void;

/**
 * Returns the value of the key from objectInfo/caseInfo
 * Added fallback to retrieve from caseInfo if objectInfo not present.
 * @param pConnect
 * @param key
 * @returns the value of key
 */
declare const getResolvedConstantValue: (pConnect: typeof PConnect, key: string) => any;

declare class UpdateWorklistService {
    private subject;
    /**
     * Function signals to update Work list
     * @param bUpdate - true: update worklist, false - do nothing
     */
    sendMessage(bUpdate: boolean): void;
    clearMessage(): void;
    getMessage(): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateWorklistService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UpdateWorklistService>;
}

export { ActionButtonsComponent, AlertBannerComponent, AlertComponent, AngularPConnectService, AppAnnouncementComponent, AppShellComponent, AssignmentCardComponent, AssignmentComponent, AttachmentComponent, AutoCompleteComponent, BannerService, BooleanFormatters, CancelAlertComponent, CaseCreateStageComponent, CaseHistoryComponent, CaseService, CaseSummaryComponent, CaseViewComponent, CheckBoxComponent, CommonFormatters, ComponentMapperComponent, ConfirmationComponent, CurrencyComponent, CurrencyFormatters, DELETE_ICON, DashboardFilterComponent, DataReferenceAdvancedSearchService, DataReferenceComponent, DatapageService, DateComponent, DateFormatters, DateTimeComponent, DecimalComponent, DefaultFormComponent, DeferLoadComponent, DetailsComponent, DetailsNarrowWideComponent, DetailsOneColumnComponent, DetailsSubTabsComponent, DetailsTemplateBase, DetailsThreeColumnComponent, DetailsTwoColumnComponent, DetailsWideNarrowComponent, DropdownComponent, EmailComponent, ErrorBoundaryComponent, ErrorMessagesService, FeedContainerComponent, FieldBase, FieldGroupListComponent, FieldGroupTemplateComponent, FieldValueListComponent, FileUtilityComponent, FlowContainerBaseComponent, FlowContainerComponent, FormTemplateBase, GoogleMapsLoaderService, Group$1 as Group, HybridViewContainerComponent, InlineDashboardComponent, InlineDashboardPageComponent, IntegerComponent, ListPageComponent, ListUtilityComponent, ListViewComponent, MaterialCaseSummaryComponent, MaterialDetailsComponent, MaterialDetailsFieldsComponent, MaterialSummaryItemComponent, MaterialSummaryListComponent, MaterialUtilityComponent, MaterialVerticalTabsComponent, ModalViewContainerComponent, MultiReferenceReadonlyComponent, MultiStepComponent, NarrowWideFormComponent, NavbarComponent, ObjectPageComponent, ObjectReferenceComponent, OneColumnComponent, OneColumnPageComponent, OneColumnTabComponent, OperatorComponent, PageComponent, PercentageComponent, PhoneComponent, PreviewViewContainerComponent, ProgressSpinnerService, PromotedFiltersComponent, PulseComponent, RadioButtonsComponent, ReferenceComponent, RegionComponent, RepeatingStructuresComponent, RichTextComponent, RichTextEditorComponent, RootContainerComponent, SdkComponentMap, SearchFormComponent, SemanticLinkComponent, ServerConfigService, SimpleTableComponent, SimpleTableManualComponent, SimpleTableSelectComponent, SingleReferenceReadonlyComponent, StagesComponent, SubTabsComponent, TABLE_CELL, TemplateUtils, TextAreaComponent, TextComponent, TextContentComponent, TextInputComponent, ThousandSeparatorDirective, ThreeColumnComponent, ThreeColumnPageComponent, TimeComponent, TodoComponent, TwoColumnComponent, TwoColumnPageComponent, TwoColumnTabComponent, UpdateWorklistService, UrlComponent, UserReferenceComponent, UtilityComponent, Utils, ViewComponent, ViewContainerComponent, WideNarrowFormComponent, WideNarrowPageComponent, buildFieldsForTable, buildFilterComponents, buildMetaForListView, buildView, combineFilters, compareSdkPCoreVersions, componentCachePersistUtils, createFilter, createFilterComponent, createMetaForTable, createPConnect, currencyMap, dateFormatInfoDefault, deleteInstruction, endpoints, evaluateAllowRowAction, filterDataByCommonFields, filterDataByDate, filterForFieldValueList, format, formatters, generateColumns, getActiveTabId, getAddRowCallback, getAllFields, getApiContext, getBanners, getCacheInfo, getComponentFromMap, getCompositeKeys, getConfigFields, getContext, getCurrencyCharacters, getCurrencyOptions, getCurrentTimezone, getData, getDataReferenceInfo, getDataRelationshipContextFromKey, getDateFormatInfo, getDeferFriendlyTabs, getFieldLabel, getFieldMeta, getFilterExpression, getFirstChildConfig, getFirstVisibleTabId, getFormattedDate, getLeafNameFromPropertyName, getLocale, getMappedKey, getMessagesGrouped, getReferenceList, getResolvedConstantValue, getSdkComponentMap, getSeconds, getTabCountSources, getTabLabel, getToDoAssignments, getTransientTabs, getVisibleTabs, handleEvent, hasAssignments, insertInstruction, isFLProperty, isLinkTextEmpty, isSelfReferencedProperty, isValidInput, loginBoxType, populateRowKey, prepareCaseSummaryData, sdkVersion, searchtabsClick, showBanner, tabClick, updateFieldLabels, updateNewInstructions, updateWorkList };
export type { AngularPConnectData, PConnFieldProps };
